// Include DTSource.h if you want to include all the headers.

#include "DTArguments.h"
#include "DTSaveError.h"

#include "DTDataFile.h"
#include "DTDoubleArray.h"
#include "DTPath3D.h"
#include "DTPointCollection3D.h"

// Common utilities
#include "DTDoubleArrayOperators.h"
#include "DTProgress.h"
#include "DTTimer.h"
#include "DTUtilities.h"
#include "DTDictionary.h"

#include <math.h>

DTPath3D Computation(const DTDoubleArray &connections,const DTPointCollection3D &points);

int main(int argc,const char *argv[])
{
    DTSetArguments(argc,argv);

    DTDataFile inputFile("Input.dtbin",DTFile::ReadOnly);
    // Read in the input variables.
    DTDoubleArray connections = inputFile.ReadDoubleArray("connections");
    DTPointCollection3D points;
    Read(inputFile,"points",points);

    // The computation.
    DTPath3D computed;
    clock_t t_before = clock();
    computed = Computation(connections,points);
    clock_t t_after = clock();
    double exec_time = double(t_after-t_before)/double(CLOCKS_PER_SEC);

    // Write the output.
    DTDataFile outputFile("Output.dtbin",DTFile::NewReadWrite);

    // Output from computation
    Write(outputFile,"Var",computed);
    outputFile.Save("Path3D","Seq_Var");

    // The execution time.
    outputFile.Save(exec_time,"ExecutionTime");
    outputFile.Save("Real Number","Seq_ExecutionTime");

    // The errors.
    DTSaveError(outputFile,"ExecutionErrors");
    outputFile.Save("StringList","Seq_ExecutionErrors");

    return 0;
}

#include "DTArrayConversion.h"

DTPath3D Computation(const DTDoubleArray &connections,const DTPointCollection3D &points)
{
    DTPath3D toReturn;
    
    DTIntArray connectionsInt = ConvertToInt(connections);
    int howMany = connectionsInt.Length();
    
    DTMutableDoubleArray loops(3,howMany);
    int pos,loc = 0,until,length;
    int howManyPoints = points.NumberOfPoints();
    DTDoubleArray pointData = ConvertToDouble(points).DoubleData();
    bool failed = false;
    while (loc<howMany && failed==false) {
        length = connectionsInt(loc);
        until = loc+1+length;
        if (length<=0 || until>howMany) {
            failed = true;
            break;
        }
        loops(0,loc) = 0;
        loops(1,loc) = 0;
        loops(2,loc) = length;
        loc++;
        while (loc<until) {
            pos = connectionsInt(loc);
            if (pos<0 || pos>=howManyPoints) {
                failed = true;
                break;
            }
            loops(0,loc) = pointData(0,pos);
            loops(1,loc) = pointData(1,pos);
            loops(2,loc) = pointData(2,pos);
            loc++;
        }
    }
    
    if (failed) {
        DTErrorMessage("Invalid input");
        return DTPath3D();
    }

    return DTPath3D(loops);
}
