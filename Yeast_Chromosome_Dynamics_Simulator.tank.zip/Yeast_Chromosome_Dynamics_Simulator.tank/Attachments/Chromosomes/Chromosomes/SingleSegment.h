//
//  SingleSegment.hpp
//  Chromosomes
//
//  Created by David Adalsteinsson on 6/20/16.
//
//

#ifndef SingleSegment_h
#define SingleSegment_h

#include "DTRandom.h"
#include "DTUtilities.h"
#include "DTPointCollection3D.h"
#include "DTDictionary.h"
#include "DTCharArray.h"
#include "DTPath3D.h"
#include "DTMatlabDataFile.h"

class SingleSegment
{
public:
    SingleSegment() {};
    // SingleSegment(const DTMutablePointCollection3D &xyPoints,const DTDictionary &coefficients);
    SingleSegment(int segmentNumber,int howManyPointsSoFar,const DTPoint3D &start,const DTPoint3D &end,double length,const DTDictionary &coefficients,const DTDictionary &terms);
    
    int NumberOfPoints(void) const {return xyLocations.NumberOfPoints();}
    
    // Individual terms
    void AddNoise(DTRandom &random,double dt,DTMutableDoubleArray &randomNoiseWorkArray);
    void SpringTerm(double t,double dt,DTMutableDoubleArray &workArray);
    void AddLoopAttraction(double t,double dt);
    
    // New loop mechanism
    void UpdateLoopConnections(DTMutableList<SingleSegment> &segmentList,double t,double dt);
    void AddLoopAttraction(DTMutableList<SingleSegment> &segmentList,double t,double dt);
    
    void ExcludedVolumeTerm(const DTList<SingleSegment> &entries,double dt);
    void Confine(double t);
    
    void UpdateAutomaticLoops(const DTDoubleArray &xy,double t);
    
    // For saving information to the file
    DTMutableDictionary StructureInfo(void) const;
    void SaveInformationToFile(DTDataStorage &);
    void SaveInformationForSegment(DTDataStorage &outputFile);
    
    void ComputeLoops(int loopLength,int betweenLoops); // Fill inthe loop structure
    
    DTIntArray OnMarkers(void) const;
    DTIntArray OffMarkers(void) const;
    
    // Key storage.  Effectively you are solving
    // Y' = F(Y), where Y consists of 32 segments, each one of them stored in this datatype (SingleSegment)
    // Y = [Y1, Y2, ..., Y32]
    // Y' = [Y1, Y2, ..., Y32]' = [F1(Y), F2(Y), ... F32(Y)]  - Yk' = Fk(Y) = Fk(Y1,...,Y32)
    DTMutablePointCollection3D xyLocations; // The position values (x,y,z).  This is Yk, k = this segment (mySegmentNumber)
    DTMutablePointCollection3D updates; // This is Fk(Y), and is accumulated and then finally used to advance Y.
    int mySegmentNumber; // This is the "k" in [Y1,Y2,...,Yk,...,Y32]
    
    
    // Parameters needed for computing the components of Fk
    // The Fk(Y) is a sum of contributions from various physical processes.
    // The 
    
    int numberOfFirstPoint; // Where the points in this segment start in the overall point list
    
    // Constants
    bool tetherEnd;
    double radius;
    double numberKuhnPerSegment;
    double L_p;
    
    // For the random noise
    double scaleForNoise;
    
    // For the excluded volume
    double SkSquared;
    double coefficientInsideExponent;
    double scaleInFrontOfExcludedVolume;
    
    // For the spring
    double scaleForSpring;
    bool segmentIsSplit;
    int whichSegmentIsSplit; // Currently only one split is allowed
    double timeWhenSegmentIsSplit;
    
    // For the loop
    double loopForceScale; //
    double loopMaxDistance;
    
    // For loops
    DTMutableIntArray loops; // 2xK array with index pairs
    // For bridging loops, this is a 3xK array.  (0,k) is a bead # here, (1,k) is the second bead and (2,k) is the arm for that bead
    
    int howManyLoops; // Used for the automatic loops to avoid reallocation
    // Dynamic loops that can cross arms
        
    // For the dynamic loops.  A certain range of beads has a given trigger time when it switches
    // This is instead of the loop.
    bool automaticLooping;
    // double automaticOnPropability;
    double automaticDistanceBarrier;
    double automaticLoopsStartAt;
    bool automaticLoopsHaveStarted;
    // DTRange automaticLoopingRangeOld;
    DTIntArray pointsThatCanBeLooped;
    
    DTMutableDoubleArray automaticLoopTrigger;
    DTMutableCharArray automaticLoopTag;
    DTMutableIntArray automaticLoopConnected;
    DTMutableDoubleArray automaticLoopWorkMatrix;
    DTMutableIntArray automaticLoopWorkList;
    DTRandom automaticRandom;
    double automaticLoopMeanTimeOn;
    double automaticLoopSigmaTimeOn;
    double automaticLoopMeanTimeOff;
    double automaticLoopSigmaTimeOff;
    
    
    // For voids
    bool shouldFormVoid;
    double voidFormsAt;
    DTPoint3D voidCenter;
    double voidRadius;
    int voidType; // 0 is inpermeable boundary, 1 is nothing inside the void
    DTCharArray pointInside; // 0 means outside, 1 means inside the void.
    
    bool confineToSphere;
};


extern DTPath3D ConvertToPath(const DTMutableList<SingleSegment> &chains);
extern DTPath3D LoopSegments(const DTMutableList<SingleSegment> &chains);

extern void SaveLoopConnectionsOffset(DTList<SingleSegment> &segments,DTMatlabDataFile &outputFile);
extern DTIntArray ComputeLoopConnectionsOffset(DTList<SingleSegment> &segments);
extern DTIntArray ComputeOnMarkers(DTList<SingleSegment> &segments);
extern DTIntArray ComputeOffMarkers(DTList<SingleSegment> &segments);

extern void AddDynamicLoops(DTMutableList<SingleSegment> &segmentList,const DTDictionary &terms,double t,double dt);
extern void AddToSumOfAllPairwiseDistances(DTMutableList<SingleSegment> &segmentList,DTMutableDoubleArray sumOfAllPairwiseDistances);

#endif /* SingleSegment_hpp */
