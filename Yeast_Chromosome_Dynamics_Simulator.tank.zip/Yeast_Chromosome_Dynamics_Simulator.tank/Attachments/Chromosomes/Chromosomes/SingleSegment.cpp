//
//  SingleSegment.cpp
//  Chromosomes
//
//  Created by David Adalsteinsson on 6/20/16.
//
//

#include "SingleSegment.h"

#include "DTPlot1D.h"

SingleSegment::SingleSegment(int segmentNumber,int howManyPointsSoFar,
                             const DTPoint3D &start,const DTPoint3D &end,double length,const DTDictionary &coefficients,const DTDictionary &terms)
{
    // end = radius*ends(startIndex(k));
    
    mySegmentNumber = segmentNumber;
    howManyLoops = 0;
    
    double numberkbPerSegment = coefficients("NumberkbPerSegment"); // Number of Kuhn  lengths per spring
    int segmLen = numberkbPerSegment*1000;
    
    int numP = round(length/segmLen) - 1;
    // if (maxLength<numP) maxLength = numP;
    DTMutableDoubleArray pointLocations(3,numP+2);
    double dx = (end.x-start.x)/(numP+1);
    double dy = (end.y-start.y)/(numP+1);
    double dz = (end.z-start.z)/(numP+1);
    int i;
    for (i=0;i<numP+2;i++) {
        pointLocations(0,i) = start.x + dx*i;
        pointLocations(1,i) = start.y + dy*i;
        pointLocations(2,i) = start.z + dz*i;
    }
    
    xyLocations = DTMutablePointCollection3D(pointLocations);
    int howManyXY = xyLocations.NumberOfPoints();
    numberOfFirstPoint = howManyPointsSoFar;
    
    numP = xyLocations.NumberOfPoints();
    DTMutableDoubleArray updateArray = DTMutableDoubleArray(3,numP);
    updateArray(0,0) = 0;
    updateArray(1,0) = 0;
    updateArray(2,0) = 0;
    updateArray(0,numP-1) = 0;
    updateArray(1,numP-1) = 0;
    updateArray(2,numP-1) = 0;
    updates = DTMutablePointCollection3D(updateArray);
    
    tetherEnd = true;
    radius = coefficients("radius");
    
    int tetherType = terms("tether");
    if (tetherType==2) {
        // Only detach a single branch
        int whichIsNotConnected = terms("disconnect tether")-1;
        if (whichIsNotConnected==segmentNumber) {
            tetherEnd = false;
        }
    }
    
    // double scaleForNoise = sqrt(2*K_bT/zetaEff)*sqrt(dt);
    double K_bT = 4.11;
    double zetaEff = coefficients("zetaEff"); // Effective drag coefficient
    scaleForNoise = sqrt(2*K_bT/zetaEff);
    
    L_p = coefficients("L_p");
    scaleForSpring = K_bT/(4*L_p)/zetaEff;
    
    // Split in segments - added 1/26/2016
    segmentIsSplit = false;
    whichSegmentIsSplit = -1;
    timeWhenSegmentIsSplit = 0.0;
    if (terms.Contains("split")) {
        DTDictionary splitDictionary = terms("split");
        if (splitDictionary("should split") && splitDictionary("segment")==segmentNumber+1) {
            // Split this segment, figure out where
            timeWhenSegmentIsSplit = splitDictionary("split time");
            double location = splitDictionary("split location");
            // Convert this into a segment
            whichSegmentIsSplit = int(floor(location/numberkbPerSegment));
            segmentIsSplit = true;
        }
    }
    
    
    numberKuhnPerSegment = 340.0 * numberkbPerSegment/(2*L_p); // Was called Nks before
    
    // For the excluded volume
    double nu = coefficients("nu"); // Excluded volume parameter
    SkSquared = numberKuhnPerSegment*(2*L_p)*(2*L_p)/6;
    coefficientInsideExponent = -3.0/(4*SkSquared); // Coefficient inside the exponent for the excluded volume
    scaleInFrontOfExcludedVolume = nu*K_bT/(zetaEff*pow(M_PI,1.5))*numberKuhnPerSegment*numberKuhnPerSegment*pow(3.0/(4.0*SkSquared),2.5);
    
    // Scale the excluded volume coefficients
    if (terms.Contains("excluded")) {
        DTDictionary excludedTweak = terms("excluded");
        if (excludedTweak("should scale")) {
            double scale = excludedTweak("scale range");
            coefficientInsideExponent /= scale*scale;
            scaleInFrontOfExcludedVolume *= excludedTweak("scale strength");
        }
    }
    
    
    // Loops
    int loopType = terms("loops");
    // 0 means no loops, 1 means loops everywhere, 2 means only a single chain, and that is specified in "loop chain"
    if (loopType==1 || loopType==2) {
        double numberPerLoop = coefficients("NumberPerLoop");
        double numberBetweenLoops = coefficients("NumberBetweenLoops");
        loopForceScale = terms("loopForceScale");
        loopMaxDistance = terms("Loop Max Distance");

        if (loopType==2) {
            // Only a single one
            int which = terms("loop chain")-1;
            if (which!=segmentNumber) {
                // Don't include this
                numberPerLoop = 0;
            }
        }
        if (numberPerLoop>0) {
            
            if (loopType==2 && terms.Contains("loop range")) {
                // Compute loops only for a particular range
                DTDoubleArray range = terms("loop range");
                int startAt = int(round(range(0)/numberkbPerSegment));
                if (startAt<1) startAt = 1;
                int endAt = int(round(range(1)/numberkbPerSegment));
                if (endAt>=howManyXY) endAt = howManyXY-1;
                int loopLength = round(numberPerLoop/numberkbPerSegment);
                int betweenLoops = round(numberBetweenLoops/numberkbPerSegment);
                
                int maxK = (endAt-startAt)/(loopLength+betweenLoops);
                int start = startAt;
                
                while (start + (loopLength+betweenLoops)*(maxK-1) + loopLength>=howManyXY-1) {
                    // This is the last index in the loop below, need to make sure that it is not out of bounds.
                    // Remove loops
                    maxK--;
                }
                
                int k;
                DTMutableIntArray theArray(2,maxK);
                for (k=0;k<maxK;k++) {
                    theArray(0,k) = start + (loopLength+betweenLoops)*k;
                    theArray(1,k) = theArray(0,k) + loopLength;
                }
                loops = theArray;
                howManyLoops = loops.n();
            }
            else {
                ComputeLoops(round(numberPerLoop/numberkbPerSegment),round(numberBetweenLoops/numberkbPerSegment));
            }
        }
    }
    
    if (loopType==4) {
        // See if "Loop #" exists as a dictionary
        std::string loopName = "Loop " + DTInt2String(segmentNumber+1);
        DTDictionary autoInformation = terms("auto looping");
        if (autoInformation.Contains(loopName)) {
            
            loopForceScale = terms("loopForceScale");
            loopMaxDistance = terms("Loop Max Distance");
            
            DTDictionary autoInformation = terms("auto looping");
            
            // Nucleolis loop, automatic trigger
            automaticLooping = true;
            DTDoubleArray range = autoInformation(loopName);
            int startAt, endAt, howMany;
            DTMutableIntArray temp;
            
            if (range.Length()==2) {
                startAt = int(round(range(0)/numberkbPerSegment));
                if (startAt<1) startAt = 1;
                endAt = int(round(range(1)/numberkbPerSegment));
                if (endAt>=howManyXY-1 || isfinite(range(1))==0) endAt = howManyXY-2;
                howMany = (endAt-startAt)+1;
                temp = DTMutableIntArray(howMany);
                for (i=0;i<howMany;i++) {
                    temp(i) = i + startAt;
                }
            }
            else if (range.Length()==3) {
                // Stride
                startAt = int(round(range(0)/numberkbPerSegment));
                if (startAt<1) startAt = 1;
                int stride = int(round(range(1)/numberkbPerSegment));
                if (stride<1) stride = 1;
                endAt = int(round(range(2)/numberkbPerSegment));
                if (endAt>=howManyXY-1 || isfinite(range(2))==0) endAt = howManyXY-2;
                howMany = (endAt-startAt)/stride+1;
                // startAt+howMany*stride>endAt
                // For example, startAt=3, endAt=7, stride=2, (7-3)/2+1 = 3, i.e. 3,5,7
                // but if endAt=6, then (6-3)/2+1 = 3/2+1 = 1+1 = 2
                temp = DTMutableIntArray(howMany);
                for (i=0;i<howMany;i++) {
                    temp(i) = i*stride + startAt;
                }
            }
            else if (range.m()==3) {
                // Array with start, stride, end in each column
                int stride,intervalN,howManyIntervals = range.n();
                DTMutableCharArray flagged(howManyXY);
                flagged = 0;
                for (intervalN=0;intervalN<howManyIntervals;intervalN++) {
                    startAt = int(round(range(0,intervalN)/numberkbPerSegment));
                    if (startAt<1) startAt = 1; // Can't start at the centromere
                    stride = int(round(range(1,intervalN)/numberkbPerSegment));
                    if (stride<=0) {
                        DTErrorMessage("Initialization","Invalid stride");
                        exit(-1);
                    }
                    if (isfinite(range(2,intervalN))) {
                        endAt = int(round(range(2,intervalN)/numberkbPerSegment));
                    }
                    else {
                        endAt = howManyXY-2; // This is Infinity
                    }
                    if (endAt>=howManyXY-1 || isfinite(range(2))==0) endAt = howManyXY-2; // One before the telomere
                    for (i=startAt;i<=endAt;i+=stride) {
                        flagged(i) = 1;
                    }
                }
                howMany = 0;
                temp = DTMutableIntArray(howManyXY);
                for (i=0;i<howManyXY;i++) {
                    if (flagged(i)) {
                        temp(howMany++) = i;
                    }
                }
                temp = TruncateSize(temp,howMany);
            }
            else {
                DTErrorMessage("Invalid input");
                exit(-1); // Abort
            }
            
            // Check to make sure the end points are not included
            if (temp(0)==0 || temp(temp.Length()-1)==howManyXY-1) {
                DTErrorMessage("Marked the centromere or telomere");
                exit(-1); // Abort
            }
            
            // automaticLoopingRangeOld = DTRange(startAt,endAt-startAt+1); // Obsolete

            pointsThatCanBeLooped = temp;
            
            automaticLoopConnected = DTMutableIntArray(2,howMany); // loop and segment
            loops = DTMutableIntArray(3,howManyXY);

            automaticLoopConnected = -1; // Not connected
            automaticLoopTrigger = DTMutableDoubleArray(howMany);
            automaticLoopTrigger = 0;
            
            automaticLoopMeanTimeOn = autoInformation("mean on");
            automaticLoopSigmaTimeOn = autoInformation("std on");
            automaticLoopMeanTimeOff = autoInformation("mean off");
            automaticLoopSigmaTimeOff = autoInformation("std off");
            // automaticOnPropability = terms("auto probability");
            automaticDistanceBarrier = autoInformation("barrier");
            
            /*
             auto worm - The singularity for the spring.
             sketch the forces and return that so that we can look at the functions
             two paremeters, linear scale and wormlike maxima
             also keep track of the typical step size (update array)
             */
            automaticLoopsStartAt = autoInformation("start");
            
            // Not every point should be tagged
            automaticRandom = DTRandom(terms.GetNumber("auto seed",4243122+segmentNumber*13));
            automaticLoopTag = DTMutableCharArray(howMany);
            // automaticLoopConnected = DTMutableIntArray(howMany);
            
            automaticLoopWorkMatrix = DTMutableDoubleArray(howMany,howMany);
            automaticLoopWorkList = DTMutableIntArray(howMany);
            
            // automaticLoopConnected = -1;
            automaticLoopsHaveStarted = false;
            
            // loop length will vary
            howManyLoops = 0;

        }
    }
    else if ((loopType==3 || loopType==4) && (terms("loop chain")-1==segmentNumber)) {
        loopForceScale = terms("loopForceScale");
        loopMaxDistance = terms("Loop Max Distance");
        
        DTDictionary autoInformation = terms("auto looping");
        
        // Nucleolis loop, automatic trigger
        automaticLooping = true;
        DTDoubleArray range = terms("loop range");
        int startAt = int(round(range(0)/numberkbPerSegment));
        if (startAt<1) startAt = 1;
        int endAt = int(round(range(1)/numberkbPerSegment));
        if (endAt>=howManyXY) endAt = howManyXY-1;
        
        // automaticLoopingRangeOld = DTRange(startAt,endAt-startAt+1);
        // int howMany = automaticLoopingRangeOld.length;
        
        int howMany = endAt-startAt+1;

        if (loopType==3) {
            automaticLoopConnected = DTMutableIntArray(howMany);
            loops = DTMutableIntArray(2,howManyXY/2);
        }
        else {
            automaticLoopConnected = DTMutableIntArray(2,howMany); // loop and segment
            loops = DTMutableIntArray(3,howManyXY);
        }
        automaticLoopConnected = -1; // Not connected
        automaticLoopTrigger = DTMutableDoubleArray(howMany);
        automaticLoopTrigger = 0;
        
        automaticLoopMeanTimeOn = autoInformation("mean on");
        automaticLoopSigmaTimeOn = autoInformation("std on");
        automaticLoopMeanTimeOff = autoInformation("mean off");
        automaticLoopSigmaTimeOff = autoInformation("std off");
        // automaticOnPropability = terms("auto probability");
        automaticDistanceBarrier = autoInformation("barrier");
        
        /*
         auto worm - The singularity for the spring.
         sketch the forces and return that so that we can look at the functions
         two paremeters, linear scale and wormlike maxima
         also keep track of the typical step size (update array)
         */
        automaticLoopsStartAt = autoInformation("start");
        
        // Not every point should be tagged
        automaticRandom = DTRandom(terms.GetNumber("auto seed",4243122+segmentNumber*13));
        automaticLoopTag = DTMutableCharArray(howMany);
        // automaticLoopConnected = DTMutableIntArray(howMany);
        
        automaticLoopWorkMatrix = DTMutableDoubleArray(howMany,howMany);
        automaticLoopWorkList = DTMutableIntArray(howMany);
        
        // automaticLoopConnected = -1;
        automaticLoopsHaveStarted = false;
        
        // loop length will vary
        howManyLoops = 0;
    }
    else {
        automaticLooping = false;
        automaticLoopsHaveStarted = false;
    }
    
    shouldFormVoid = false;
    voidFormsAt = 0.0;
    voidCenter = DTPoint3D(0,0,0);
    voidRadius = 0.0;
    if (terms.Contains("void")) {
        DTDictionary voidInfo = terms("void");
        if (voidInfo("create void")) {
            shouldFormVoid = true;
            voidFormsAt = voidInfo("void time");
            DTDoubleArray point = voidInfo("center");
            voidCenter = DTPoint3D(point(0),point(1),point(2));
            voidRadius = voidInfo("radius");
            voidType = voidInfo("type");
        }
    }
    
    confineToSphere = terms("confine");
}

void SingleSegment::AddNoise(DTRandom &random,double dt,DTMutableDoubleArray &randomNoiseWorkArray)
{
    // sqrt(2K_b*T*drag)*sqrt(dt)
    // drag = 6*pi*eta*A
    // eta = viscosity 10^-8 pNs/(nm)^2
    // drag = A = radius of bead = 10nm
    // sqrt(4.11*
    
    int numP = updates.NumberOfPoints();
    
    int firstIndex = 0;
    int lastIndex = numP;
    
    if (tetherEnd) {
        lastIndex = numP-1;
    }
    firstIndex = 1; // Tether start
    // if (tether) {
    //    firstIndex = 1;
    //    lastIndex = numP-1;
    //}
    
    random.Normal(randomNoiseWorkArray.Pointer(),3*(lastIndex-firstIndex));
    DTMutableDoubleArray a = updates.DoubleData();
    // scaleForNoise = sqrt(dt)*noise
    // a(1:1+numP) += randomNoiseWorkArray(0:numP)*scaleForNoise
    AddToColumnRange(a,DTRange(firstIndex,lastIndex-firstIndex),
                     randomNoiseWorkArray,DTRange(0,lastIndex-firstIndex),
                     scaleForNoise*sqrt(dt));
}

void SingleSegment::SpringTerm(double t,double dt,DTMutableDoubleArray &workArray)
{
    // ********************************************************************************
    // Old force calculation was based on a linear spring model.  Changed 4/29/15
    // Compute
    // linear*(X(i+1) - 2*X(i) + X(i-1))*dt
    // linear = 3*k_B*T/(2L_p)^2
    // k_B*T = 4.11e-21 Nm - L_p = persistence length - 50nm
    // If force is in pN, length in nm, then
    // k_B*T = 4.11 pN*nm, L_p = 50, so this coefficient is 5.1/(100)^2 = 5.1e-4
    
    double overallScale = dt*scaleForSpring; // zetaEff added 5/18
    // double overallScale = dt*K_bT/(4*L_p);
    // DEBUG: overallScale = 0.000002055
    double R0 = 2*numberKuhnPerSegment*L_p;
    // DEBUG: 1700
    double ratio,scale;
    double dx,dy,dz,r;
    
    
    DTDoubleArray xy = xyLocations.DoubleData();
    DTMutableDoubleArray updateArray = updates.DoubleData();
    int i;
    int numP = xyLocations.NumberOfPoints()-2;
    
    // Compute the force
    for (i=0;i<numP+1;i++) {
        dx = xy(0,i+1)-xy(0,i);
        dy = xy(1,i+1)-xy(1,i);
        dz = xy(2,i+1)-xy(2,i);
        r = sqrt(dx*dx+dy*dy+dz*dz); // This is R_i
        // Compute the expression
        ratio = r/R0;
        
        // The velocity is scaleForSpring*(1.0/((1-ratio)*(1-ratio)) - 1.0 + 4*ratio)
        // The direction vector is (dx/r,dy/r,dz/r)
        // the time step is dt, so change in x is
        // dt*scaleForSpring*(1.0/((1-ratio)*(1-ratio)) - 1.0 + 4*ratio)*dx/r
        // overallScale*(1.0/((1-ratio)*(1-ratio)) - 1.0 + 4*ratio)/r*dx
        // Same for y and z.
        
        scale = overallScale*(1.0/((1-ratio)*(1-ratio)) - 1.0 + 4*ratio)/r; // Divide by r is here instead of dx/r
        workArray(0,i) = scale*dx; // 1/r*dx = x component of the normal
        workArray(1,i) = scale*dy;
        workArray(2,i) = scale*dz;
    }
    
    // An option was added 1/26/2016 to split a segment.  This affects the spring calculation
    // since it means that one of the springs has been removed, so
    // the above calculation should have skipped over a segment.  Implement that here by just
    // setting the force to 0.
    if (segmentIsSplit && t>=timeWhenSegmentIsSplit) {
        workArray(0,whichSegmentIsSplit) = 0;
        workArray(1,whichSegmentIsSplit) = 0;
        workArray(2,whichSegmentIsSplit) = 0;
    }
    
    
    // Now go through the force calculations and compute the net force
    // which is force i minus force (i-1)
    for (i=1;i<numP+1;i++) {
        updateArray(0,i) += workArray(0,i) - workArray(0,i-1);
        updateArray(1,i) += workArray(1,i) - workArray(1,i-1);
        updateArray(2,i) += workArray(2,i) - workArray(2,i-1);
    }
    
    if (tetherEnd==false) {
        i = numP+1;
        updateArray(0,i) += - workArray(0,i-1);
        updateArray(1,i) += - workArray(1,i-1);
        updateArray(2,i) += - workArray(2,i-1);
    }

    /*
    if (tether==0) {
        // If I don't tether the points, the end points are free to move
        i = 0;
        updateArray(0,i) += workArray(0,i);
        updateArray(1,i) += workArray(1,i);
        updateArray(2,i) += workArray(2,i);
        i = numP+1;
        updateArray(0,i) += - workArray(0,i-1);
        updateArray(1,i) += - workArray(1,i-1);
        updateArray(2,i) += - workArray(2,i-1);
    }
    */
}

DTIntArray SingleSegment::OnMarkers(void) const
{
    if (automaticLooping==false) return DTIntArray();
    
    int i,howMany = automaticLoopTag.Length();
    if (howMany==0) return DTIntArray();
    
    DTMutableIntArray toReturn(howMany);
    int pos = 0;
    for (i=0;i<howMany;i++) {
        if (automaticLoopTag(i)==1) {
            // toReturn(pos++) = i + automaticLoopingRange.start + numberOfFirstPoint;
            toReturn(pos++) = pointsThatCanBeLooped(i) + numberOfFirstPoint;
        }
    }
    return TruncateSize(toReturn,pos);
}

DTIntArray SingleSegment::OffMarkers(void) const
{
    if (automaticLooping==false) return DTIntArray();
    
    int i,howMany = automaticLoopTag.Length();
    DTMutableIntArray toReturn(howMany);
    int pos = 0;
    for (i=0;i<howMany;i++) {
        if (automaticLoopTag(i)==0) {
            // toReturn(pos++) = i + automaticLoopingRange.start + numberOfFirstPoint;
            toReturn(pos++) = pointsThatCanBeLooped(i) + numberOfFirstPoint;
        }
    }
    return TruncateSize(toReturn,pos);
}

void SingleSegment::UpdateAutomaticLoops(const DTDoubleArray &xy,double t)
{
    // Rule here is as follows.  If automaticLoopConnected(i)==-1 and automaticLoopTag(i)==1 this marker
    // is ready for a connection but not connected yet.
    
    // int i,howMany = automaticLoopingRangeOld.length;
    int i, howMany = pointsThatCanBeLooped.Length();
    
    if (automaticLoopsHaveStarted==false) {
        if (t<automaticLoopsStartAt) {
            howManyLoops = 0;
            return;
        }
        automaticLoopsHaveStarted = true;
        
        double timeInCycle;
        double cycleTime = automaticLoopMeanTimeOn+automaticLoopMeanTimeOff;
        double automaticOnPropability = automaticLoopMeanTimeOn/cycleTime;
        for (i=0;i<howMany;i++) {
            // Initially spread the expiration points uniformly.  If p = percentage on at any given time
            timeInCycle = automaticRandom.UniformHalf()*cycleTime;
            if (timeInCycle<automaticLoopMeanTimeOn) {
                // Considered on
                automaticLoopTag(i) = 1;
                automaticLoopTrigger(i) = automaticLoopsStartAt+timeInCycle;
            }
            else {
                // Off
                automaticLoopTag(i) = 0;
                automaticLoopTrigger(i) = automaticLoopsStartAt+timeInCycle - cycleTime*automaticOnPropability;
            }
        }
    }
    
    // Step 1: go over the beads and see which one should be disconnected.  If so, compute the time it should reconnect.
    // Step 2: go over the beads and see which points should be set up for connection.  If so, compute the time it should disconnect
    // Step 3: Go over the points that are not connected but should be and see if they are within the radius of connection
    //         If so make the connection from the smallest to the largest distance.
    // Step 4: Remake the loop data structure so that the force calculation will work
    
    bool loopsMightChange = false;
    
    // ************************************
    // Step 1:  Check if a connecting breaks.
    for (i=0;i<howMany;i++) {
        if (automaticLoopTag(i)==1 && automaticLoopTrigger(i)<=t) {
            automaticLoopTag(i) = 0;
            // Compute a new on time
            automaticLoopTrigger(i) += automaticRandom.Normal(automaticLoopMeanTimeOff,automaticLoopSigmaTimeOff);
            if (automaticLoopConnected(i)>=0) {
                // This point was part of a loop, needs to be disconnected
                automaticLoopConnected(automaticLoopConnected(i)) = -1;
                automaticLoopConnected(i) = -1;
                loopsMightChange = true;
            }
        }
    }
    
    // ************************************
    // Step 2:
    for (i=0;i<howMany;i++) {
        if (automaticLoopTag(i)==0 && automaticLoopTrigger(i)<=t) {
            automaticLoopTag(i) = 1;
            // Compute a new off time.  There is a tiny chance that this will be before the current time but that will be addressed in the next time step
            automaticLoopTrigger(i) += automaticRandom.Normal(automaticLoopMeanTimeOn,automaticLoopSigmaTimeOn);
        }
    }
    
    // ************************************
    // Step 3:
    int howManyPoints = 0;
    for (i=0;i<howMany;i++) {
        if (automaticLoopConnected(i)==-1 && automaticLoopTag(i)==1) {
            automaticLoopWorkList(howManyPoints++) = i;
        }
    }
    
    // automaticDistanceBarrier
    // automaticLoopsStartAt
    
    // Now use the howManyPoints x howManyPoints block in automaticLoopWorkMatrix and compute the lengths.
    int j,pt1,pt2;
    double x1,y1,z1;
    double x2,y2,z2;
    double dx,dy,dz;
    double distance;
    for (i=1;i<howManyPoints;i++) {
        pt1 = automaticLoopConnected(automaticLoopConnected(i)); // The position in the xy list for this segment.
        // pt1 = automaticLoopWorkList(i)+automaticLoopingRangeOld.start;
        x1 = xy(0,pt1);
        y1 = xy(1,pt1);
        z1 = xy(2,pt1);
        for (j=0;j<i;j++) {
            pt2 = automaticLoopConnected(automaticLoopConnected(j)); // The position in the xy list for this segment.
            // pt2 = automaticLoopWorkList(j)+automaticLoopingRangeOld.start;
            x2 = xy(0,pt2);
            y2 = xy(1,pt2);
            z2 = xy(2,pt2);
            dx = x1-x2;
            dy = y1-y2;
            dz = z1-z2;
            distance = sqrt(dx*dx+dy*dy+dz*dz);
            automaticLoopWorkMatrix(i,j) = distance;
        }
    }
    
    int smallestI,smallestJ;
    double smallestValue;
    while (1) {
        smallestI = 0;
        smallestJ = 0;
        smallestValue = automaticDistanceBarrier;
        
        for (i=0;i<howManyPoints;i++) {
            for (j=0;j<i;j++) {
                if (automaticLoopWorkMatrix(i,j)<smallestValue) {
                    smallestI = i;
                    smallestJ = j;
                    smallestValue = automaticLoopWorkMatrix(i,j);
                }
            }
        }
        if (smallestValue==automaticDistanceBarrier) {
            // Nothing smaller.
            break;
        }
        
        loopsMightChange = true;
        
        // Change things so that they won't be connected to anything else.
        i = smallestI;
        for (j=0;j<i;j++) automaticLoopWorkMatrix(i,j) = automaticDistanceBarrier;
        i = smallestJ;
        for (j=0;j<i;j++) automaticLoopWorkMatrix(i,j) = automaticDistanceBarrier;
        j = smallestI;
        for (i=j+1;i<howManyPoints;i++) automaticLoopWorkMatrix(i,j) = automaticDistanceBarrier;
        j = smallestJ;
        for (i=j+1;i<howManyPoints;i++) automaticLoopWorkMatrix(i,j) = automaticDistanceBarrier;
        
        // Tie together beads smallestI and smallestJ.
        smallestI = automaticLoopWorkList(smallestI); // The position in the loop points (compatible with automaticLoopConnected and Tag)
        smallestJ = automaticLoopWorkList(smallestJ);
        automaticLoopConnected(smallestI) = smallestJ;
        automaticLoopConnected(smallestJ) = smallestI;
    }
    
    // ************************************
    // Step 4:
    // Now create the loops.
    if (loopsMightChange) {
        howManyLoops = 0;
        for (i=0;i<howMany;i++) {
            if (automaticLoopConnected(i)>=0 && automaticLoopConnected(i)<i) {
                // This point is connected to a second point that is earlier in the list
                // loops(0,howManyLoops) = automaticLoopConnected(i)+automaticLoopingRangeOld.start; // The position in the xy list for this segment.
                // loops(1,howManyLoops) = i+automaticLoopingRangeOld.start;
                loops(0,howManyLoops) = automaticLoopConnected(automaticLoopConnected(i)); // The position in the xy list for this segment.
                loops(1,howManyLoops) = pointsThatCanBeLooped(i);
                howManyLoops++;
            }
        }
    }
}

void SingleSegment::UpdateLoopConnections(DTMutableList<SingleSegment> &segmentList,double t,double dt)
{
    DTDoubleArray xy = xyLocations.DoubleData();
    UpdateAutomaticLoops(xy,t);
}

void SingleSegment::AddLoopAttraction(DTMutableList<SingleSegment> &segmentList,double t,double dt)
{
    if (howManyLoops==0) return;
    
    int i;
    int from, to;
    
    DTDoubleArray xy = xyLocations.DoubleData();
    double dx,dy,dz,r;
    DTMutableDoubleArray updateArray = updates.DoubleData();
    
    // On 6/20/2016, changed how the spring works.   The spring is now a wormlike spring but
    // with a shorter maximum distance (R0) than the normal spring, as well as a different spring constant
    
    double R0 = 2*numberKuhnPerSegment*L_p;
    double RSmall = loopMaxDistance;
    double xF,yF,zF,nx,ny,nz;
    double maxR = 0.9999*RSmall;
    double ratioSmall,distance;
    
    double overallScale = dt*loopForceScale*scaleForSpring*RSmall/R0;
    
    if (loops.m()==3) {
        int segment;
        // Connections across segments
        // (0,k) is a bead # here, (1,k) is the second bead and (2,k) is the arm for that bead

        for (i=0;i<howManyLoops;i++) {
            from = loops(0,i);
            to = loops(1,i);
            segment = loops(2,i);
            DTDoubleArray xySegment = segmentList(segment).xyLocations.DoubleData();
         
            dx = xySegment(0,to)-xy(0,from);
            dy = xySegment(1,to)-xy(1,from);
            dz = xySegment(2,to)-xy(2,from);
            
            // Standard spring force is
            // K_bT/(4*L_p)*(1.0/((1-ratio)*(1-ratio)) - 1.0 + 4*ratio)
            // where ratio = r/R0 and R0 = 2*numberKuhnPerSegment*L_p
            
            // Want to scale this force by loopForceScale
            // and move the singularity (wormlike effect) to loopMaxDistance, to acomplish that I use
            // RSmall = loopMaxDistance
            // ratioSmall = r/RSmall.  And the scaled force is therefore
            // loopForceScale*K_bT/(4*L_p)*(1.0/((1-ratioSmall)*(1-ratioSmall)) - 1.0 + 4*ratioSmall)*RSmall/R0
            
            // To get the velocity divide by zetaEff.  Since scaleForSpring = K_bT/(4*L_p)/zetaEff;
            // This means that the velocity is
            // loopForceScale*scaleForSpring*(1.0/((1-ratioSmall)*(1-ratioSmall)) - 1.0 + 4*ratioSmall)*RSmall/R0
            
            // The direction vector is (dx/r,dy/r,dz/r) = (nx,ny,nz)
            // the time step is dt, so change in x is
            // dt*loopForceScale*scaleForSpring*(1.0/((1-ratioSmall)*(1-ratioSmall)) - 1.0 + 4*ratioSmall)*RSmall/R0*nx
            // Define
            // overallScale = dt*loopForceScale*scaleForSpring*RSmall/R0
            // and the change in x becomes
            // overallScale*(1.0/((1-ratioSmall)*(1-ratioSmall)) - 1.0 + 4*ratioSmall)*nx
            
            r = sqrt(dx*dx+dy*dy+dz*dz); // This is R_i
            if (r>1e-10) {
                nx = dx/r;
                ny = dy/r;
                nz = dz/r;
            }
            else {
                // Should not happen, the points are at the same location.
                DTErrorMessage("Invalid");
                nx = ny = nz = 0.0;
            }
            
            if (r>maxR) {
                r = maxR; // So that the ratio will be less than 0.9999
            }
            // New version
            ratioSmall = r/RSmall;
            distance = overallScale*(1.0/((1-ratioSmall)*(1-ratioSmall)) - 1.0 + 4*ratioSmall);
            xF = distance*nx;
            yF = distance*ny;
            zF = distance*nz;
            
            // Can't shrink the distance by more than 50%.
            if (distance>r*0.25) {
                // scale*nx = dx*0.25, so
                distance = r*0.25;
                xF = distance*nx;
                yF = distance*ny;
                zF = distance*nz;
            } // Else it was small enough
            else {
                xF = xF;
            }
            
            updateArray(0,from) += xF;
            updateArray(1,from) += yF;
            updateArray(2,from) += zF;
        }
    }
    else {
        for (i=0;i<howManyLoops;i++) {
            from = loops(0,i);
            to = loops(1,i);
            
            dx = xy(0,to)-xy(0,from);
            dy = xy(1,to)-xy(1,from);
            dz = xy(2,to)-xy(2,from);
            
            r = sqrt(dx*dx+dy*dy+dz*dz); // This is R_i
            nx = dx/r;
            ny = dy/r;
            nz = dz/r;
            
            if (r>maxR) {
                r = maxR; // So that the ratio will be less than 0.9999
            }

            ratioSmall = r/RSmall;
            distance = overallScale*(1.0/((1-ratioSmall)*(1-ratioSmall)) - 1.0 + 4*ratioSmall);
            xF = distance*nx;
            yF = distance*ny;
            zF = distance*nz;
            
            // Can't shrink the distance by more than 50%.
            if (distance>r*0.25) {
                // scale*nx = dx*0.25, so
                distance = r*0.25;
                xF = distance*nx;
                yF = distance*ny;
                zF = distance*nz;
            } // Else it was small enough

            updateArray(0,from) += xF;
            updateArray(1,from) += yF;
            updateArray(2,from) += zF;
        }
    }
    
    // Remove
    //if (ContainsNonFinite(updateArray)) {
    //    DTErrorMessage("Non-finite");
    //}
}

void SingleSegment::AddLoopAttraction(double t,double dt)
{
    if (loops.Length()==0 && automaticLooping==false) {
        return;
    }
    
    int i;
    int from, to;
    
    DTDoubleArray xy = xyLocations.DoubleData();
    double dx,dy,dz,r;
    DTMutableDoubleArray updateArray = updates.DoubleData();
    
    if (automaticLooping) {
        // Looping changes on the fly
        UpdateAutomaticLoops(xy,t);
    }
    
    // On 6/20/2016, changed how the spring works.   The spring is now a wormlike spring but
    // with a shorter maximum distance (R0) than the normal spring, as well as a different spring constant
    

    double R0 = 2*numberKuhnPerSegment*L_p;
    double RSmall = loopMaxDistance;
    double xF,yF,zF,nx,ny,nz;
    double maxR = 0.9999*RSmall;
    double ratioSmall, distance;
    
    double overallScale = dt*loopForceScale*scaleForSpring*RSmall/R0;

    for (i=0;i<howManyLoops;i++) {
        from = loops(0,i);
        to = loops(1,i);
        
        dx = xy(0,to)-xy(0,from);
        dy = xy(1,to)-xy(1,from);
        dz = xy(2,to)-xy(2,from);
        
        r = sqrt(dx*dx+dy*dy+dz*dz); // This is R_i
        nx = dx/r;
        ny = dy/r;
        nz = dz/r;
        
        if (r>maxR) {
            r = maxR; // So that the ratio will be less than 0.9999
        }
        
        ratioSmall = r/RSmall;
        distance = overallScale*(1.0/((1-ratioSmall)*(1-ratioSmall)) - 1.0 + 4*ratioSmall);
        xF = distance*nx;
        yF = distance*ny;
        zF = distance*nz;
        
        // Can't shrink the distance by more than 50%.
        if (distance>r*0.25) {
            // scale*nx = dx*0.25, so
            distance = r*0.25;
            xF = distance*nx;
            yF = distance*ny;
            zF = distance*nz;
        }
        
        updateArray(0,from) += xF;
        updateArray(1,from) += yF;
        updateArray(2,from) += zF;
        updateArray(0,to) -= xF;
        updateArray(1,to) -= yF;
        updateArray(2,to) -= zF;
        
        /* Old version
         
         scale = scaleForceBy/r;
         
         updateArray(0,from) += scale*dx;
         updateArray(1,from) += scale*dy;
         updateArray(2,from) += scale*dz;
         updateArray(0,to) += -scale*dx;
         updateArray(1,to) += -scale*dy;
         updateArray(2,to) += -scale*dz;
         
         */
    }
}

void SingleSegment::ExcludedVolumeTerm(const DTList<SingleSegment> &segmentList,double dt)
{
    // i'th point is coefficientInFrontOfExcludedVolume*sum_j [ (X_i - X_j) * exp( C1*||X_i-X_j|^2) ]
    //             = coefficientInFrontOfExcludedVolume*sum_j [ (X_i - X_j) * exp( C1*||X_i-X_j|^2) ]
    // where j is the sum over all of the other points
    // scaleC0 = C0*0.5*Nsw*dt;
    
    
    // Coefficient in front of exponent is
    // z*k_s/(2d^5)
    // z is the strength of the repulsion - input parameter
    // k_s = 3*k_B*T/(2L_p)^2
    // d = 0.72 - but this should be an input argument
    // z/d^5 = between 1 and 5
    
    // Coefficient inside exp(-...) is
    // -k_s/(2k_BT)/d^2 = 3*k_B*T/(2L_p)^2/(2k_B*T)/d^2 = 3/(8L_p^2d^2)
    // d = 0.72
    // L_p = 50nm
    int kInner,Nc = segmentList.Length();
    
    DTDoubleArray xy = xyLocations.DoubleData();
    int numP = xyLocations.NumberOfPoints();
    DTMutableDoubleArray updateArray = updates.DoubleData();
    int firstIndex = 0;
    int lastIndex = numP;
    
    if (tetherEnd) {
        lastIndex = numP-1;
    }
    firstIndex = 1;
    
    //if (tether) {
    //    firstIndex = 1;
    //    lastIndex = numP-1;
    //}
    
    double x,y,z,sumX,sumY,sumZ,dx,dy,dz,arg,scale;
    double zeroBelow = log(1e-6);
    int i,j,innerN;
    DTDoubleArray xyCoordsInside;
    const double *xyCoordsInsideD;
    
    double coefficientInFrontOfExcludedVolume = scaleInFrontOfExcludedVolume*dt;
    const SingleSegment *segmentListD = segmentList.Pointer();
    
    for (i=firstIndex;i<lastIndex;i++) { // On each chain, go through the middle points (not the edges)
        x = xy(0,i);
        y = xy(1,i);
        z = xy(2,i);
        // Compute the force by all of the other beads.  This includes points on the other chains as well as end points
        sumX = sumY = sumZ = 0.0;
        for (kInner=0;kInner<Nc;kInner++) {
            xyCoordsInside = segmentListD[kInner].xyLocations.DoubleData();
            xyCoordsInsideD = xyCoordsInside.Pointer();
            innerN = segmentListD[kInner].xyLocations.NumberOfPoints();
            for (j=0;j<innerN;j++) {
                dx = x - xyCoordsInsideD[3*j];
                dy = y - xyCoordsInsideD[1+3*j];
                dz = z - xyCoordsInsideD[2+3*j];
                arg = coefficientInsideExponent*(dx*dx + dy*dy + dz*dz);
                
                // Note.  When (j,kInner) = (i,currentSegment), the argument is 0. so scale will be 1.  But dx==dy==dz = 0 so nothing will be added.
                if (arg<zeroBelow) {
                    // Far away, don't want to call the exp function.
                    scale = 0.0;
                }
                else {
                    scale = exp(arg);
                    sumX += scale*dx;
                    sumY += scale*dy;
                    sumZ += scale*dz;
                }
            }
        }
        
        // This is done in the beginning, so I don't need a +=
        updateArray(0,i) = coefficientInFrontOfExcludedVolume*sumX;
        updateArray(1,i) = coefficientInFrontOfExcludedVolume*sumY;
        updateArray(2,i) = coefficientInFrontOfExcludedVolume*sumZ;
    }
}

void SingleSegment::Confine(double t)
{
    DTMutableDoubleArray canChange = xyLocations.DoubleData();
    int i;
    int numP = xyLocations.NumberOfPoints();
    
    if (confineToSphere) {
        // Don't allow any motion through the boundary (radius Dsep)
        
        int firstIndex = 0;
        int lastIndex = numP;
        if (tetherEnd) {
            lastIndex = numP-1;
        }
        firstIndex = 1;
        
        //if (tether) {
        //    firstIndex = 1;
        //    lastIndex = numP-1;
        //}

        double x,y,z,len;
        
        for (i=firstIndex;i<lastIndex;i++) {
            x = canChange(0,i);
            y = canChange(1,i);
            z = canChange(2,i);
            len = sqrt(x*x+y*y+z*z);
            if (len>radius) {
                canChange(0,i) = x*radius/len;
                canChange(1,i) = y*radius/len;
                canChange(2,i) = z*radius/len;
            }
        }
    }
    
    if (shouldFormVoid && t>voidFormsAt) {
        // Could be the first time
        DTPoint3D c = voidCenter;
        double vR = voidRadius;
        double dx,dy,dz,distanceNow;
        if (voidType==0) {
            if (pointInside.Length()==0) { // Block based on the current position
                DTMutableCharArray pointList(canChange.n());
                for (i=0;i<numP;i++) {
                    dx = canChange(0,i)-c.x;
                    dy = canChange(1,i)-c.y;
                    dz = canChange(2,i)-c.z;
                    distanceNow = sqrt(dx*dx+dy*dy+dz*dz);
                    pointList(i) = (distanceNow<vR);
                }
                pointInside = pointList;
            }
            else {
                // Enforce the boundary
                for (i=0;i<numP;i++) {
                    dx = canChange(0,i)-c.x;
                    dy = canChange(1,i)-c.y;
                    dz = canChange(2,i)-c.z;
                    distanceNow = sqrt(dx*dx+dy*dy+dz*dz);
                    if (pointInside(i)) {
                        // Started inside, should stay inside
                        if (distanceNow>vR) {
                            if (vR<0.001) {
                                // Inaccurate.  Really shouldn't happen
                                canChange(0,i) = c.x;
                                canChange(1,i) = c.y;
                                canChange(2,i) = c.z + vR;
                            }
                            else {
                                canChange(0,i) = c.x + dx*vR/distanceNow;
                                canChange(1,i) = c.y + dy*vR/distanceNow;
                                canChange(2,i) = c.z + dz*vR/distanceNow;
                            }
                        }
                    }
                    else {
                        // Started outside, should stay outside
                        if (distanceNow<vR) {
                            canChange(0,i) = c.x + dx*vR/distanceNow;
                            canChange(1,i) = c.y + dy*vR/distanceNow;
                            canChange(2,i) = c.z + dz*vR/distanceNow;
                        }
                    }
                }
            }
        }
        else {
            // Nothing can be inside, so everything should be moved to the boundary of the void.
            // Enforce the boundary
            for (i=0;i<numP;i++) {
                dx = canChange(0,i)-c.x;
                dy = canChange(1,i)-c.y;
                dz = canChange(2,i)-c.z;
                distanceNow = sqrt(dx*dx+dy*dy+dz*dz);
                if (distanceNow<vR) {
                    canChange(0,i) = c.x + dx*vR/distanceNow;
                    canChange(1,i) = c.y + dy*vR/distanceNow;
                    canChange(2,i) = c.z + dz*vR/distanceNow;
                }
            }
        }
    }
}

void SingleSegment::ComputeLoops(int loopLength,int betweenLoops)
{
    int howManyXY = xyLocations.NumberOfPoints();
    
    // The location of the start is
    // start + (loopLength+betweenLoops)*K
    // The location of the end is
    // start + (loopLength+betweenLoops)*K + loopLength
    // Want  start = howManyXY - (start + (loopLength+betweenLoops)*K + loopLength)
    // That is 2*start = howManyXY - ((loopLength+betweenLoops)*K + loopLength)
    //                 = howManyXY - loopLength - (loopLength+betweenLoops)*K > 0
    int maxK = (howManyXY - (loopLength-1))/(loopLength+betweenLoops);
    int start = (howManyXY - ((loopLength+betweenLoops)*maxK + loopLength))/2;
    
    if (start<=1 || start + (loopLength+betweenLoops)*maxK + loopLength>=howManyXY-1) {
        // Remove one loop
        maxK--;
        start = (howManyXY - ((loopLength+betweenLoops)*maxK + loopLength))/2;
    }
    
    int k,howManyLoops = maxK+1;
    DTMutableIntArray theArray(2,howManyLoops);
    for (k=0;k<howManyLoops;k++) {
        theArray(0,k) = start + (loopLength+betweenLoops)*k;
        theArray(1,k) = theArray(0,k) + loopLength;
    }
    
    if (theArray(1,howManyLoops-1)>=howManyXY-1) {
        DTErrorMessage("SingleSegment::ComputeLoops","Invalid end");
    }
    loops = theArray;
    howManyLoops = loops.n();
}

DTMutableDictionary SingleSegment::StructureInfo(void) const
{
    DTMutableDictionary toReturn;
    
    if (howManyLoops!=0) {
        // Create a number of entries
        
        // Segments between connections, ignore the start and end
        int i,j,N,pos;
        N = howManyLoops;
        pos = 0;
        
        DTMutableDoubleArray between((N-1)*3);
        int start,end;
        for (i=0;i<N-1;i++) {
            start = loops(1,i);
            end = loops(0,i+1);
            if (pos+(end-start)+1>between.Length())
                between = IncreaseSize(between,between.Length());
            between(pos++) = end-start+1;
            for (j=start;j<=end;j++) {
                between(pos++) = j+numberOfFirstPoint;
            }
        }
        if (between.Length()!=pos) between = TruncateSize(between,pos);
        toReturn("Between Loops") = between;
        
        // The actual loops, will contain the start and end bead
        DTMutableDoubleArray loopPoints(xyLocations.NumberOfPoints()+N);
        pos = 0;
        for (i=0;i<N;i++) {
            start = loops(0,i);
            end = loops(1,i);
            loopPoints(pos++) = end-start+1;
            for (j=start;j<=end;j++) {
                loopPoints(pos++) = j+numberOfFirstPoint;
            }
        }
        loopPoints = TruncateSize(loopPoints,pos);
        toReturn("Loop") = loopPoints;
        
        // Backbone in terms of point offsets.  That is the points ignoring the loops
        DTMutableDoubleArray backbone(xyLocations.NumberOfPoints());
        pos = 1;
        start = 0;
        end = loops(0,0);
        for (j=start;j<=end;j++)
            backbone(pos++) = j+numberOfFirstPoint;
        for (i=0;i<N-1;i++) {
            start = loops(1,i);
            end = loops(0,i+1);
            for (j=start;j<=end;j++) {
                backbone(pos++) = j+numberOfFirstPoint;
            }
        }
        // The end
        start = loops(1,N-1);
        end = xyLocations.NumberOfPoints();
        for (j=start;j<end;j++)
            backbone(pos++) = j+numberOfFirstPoint;
        backbone(0) = pos-1;
        backbone = TruncateSize(backbone,pos);
        toReturn("Backbone") = backbone;
        
        /*
         Indices of the backbone
         int numberOfPoints = xyLocations.NumberOfPoints();
         DTMutableDoubleArray whichLocation(numberOfPoints);
         int focus = 0;
         
         int howMany = loops.n();
         for (i=0;i<howMany;i++) {
         while (focus<=loops(0,i))
         whichLocation(pos++) = focus++;
         focus = loops(1,i);
         whichLocation(pos++) = focus++;
         }
         // Add the tail
         while (focus<numberOfPoints)
         whichLocation(pos++) = focus++;
         
         whichLocation = TruncateSize(whichLocation,pos);
         
         toReturn("Backbone") = whichLocation;
         */
    }
    
    if (segmentIsSplit) { // Added 1/26/2016
        // Add the offset of the point before and after the split so we can monitor it.
        // This number is 1 based for DataTank
        toReturn("Before split") = whichSegmentIsSplit+numberOfFirstPoint+1;
        toReturn("After split") = whichSegmentIsSplit+numberOfFirstPoint+1+1;
    }
    
    return toReturn;
}

void SingleSegment::SaveInformationToFile(DTDataStorage &outputFile)
{
    // i'th point is coefficientInFrontOfExcludedVolume*sum_j [ (X_i - X_j) * exp( C1*||X_i-X_j|^2) ]
    //             = coefficientInFrontOfExcludedVolume*sum_j [ (X_i - X_j) * exp( C1*||X_i-X_j|^2) ]
    // where j is the sum over all of the other points
    // scaleC0 = C0*0.5*Nsw*dt;
    
    
    double dr = 0.1;
    double howMany = 1000/dr;
    int i;
    DTMutableDoubleArray xy(2,1+howMany);
    double r,arg,scale;
    xy(0,0) = 0;
    xy(1,0) = howMany;
    for (i=0;i<howMany;i++) {
        r = i*dr;
        arg = coefficientInsideExponent*(r*r);
        scale = scaleInFrontOfExcludedVolume*exp(arg);
        xy(0,i+1) = r;
        xy(1,i+1) = scale;
    }
    
    DTPlot1D thePlot(xy);
    WriteOne(outputFile,"ExcludedVolume",thePlot);
    
    // Save out the force calculation
    double overallScale = scaleForSpring; // zetaEff added 5/18
    // double overallScale = dt*K_bT/(4*L_p);
    // DEBUG: overallScale = 0.000002055
    double R0 = 2*numberKuhnPerSegment*L_p;
    // DEBUG: 1700
    double ratio;
    howMany = 500;
    dr = R0/howMany;

    DTMutableDoubleArray forcePlot(2,howMany+1);
    forcePlot(0,0) = 0;
    forcePlot(1,0) = howMany;
    
    // Compute the force as a function of distance
    for (i=0;i<howMany;i++) {
        r = i*dr;
        // Compute the expression
        ratio = r/R0;
        scale = overallScale*(1.0/((1-ratio)*(1-ratio)) - 1.0 + 4*ratio); // Includes the normal
        forcePlot(0,i+1) = r;
        forcePlot(1,i+1) = scale;
    }

    DTPlot1D theForce(forcePlot);
    WriteOne(outputFile,"SpringForce",theForce);
}

void SingleSegment::SaveInformationForSegment(DTDataStorage &outputFile)
{
    if (automaticLooping) {
        // Save the force calculation

        // Save out the force calculation
        double overallScale = scaleForSpring; // zetaEff added 5/18
        // double overallScale = dt*K_bT/(4*L_p);
        // DEBUG: overallScale = 0.000002055
        double R0 = loopMaxDistance;
        // DEBUG: 1700
        int howMany = 500;
        double dr = R0/howMany;
        
        DTMutableDoubleArray forcePlot(2,howMany+1);
        forcePlot(0,0) = 0;
        forcePlot(1,0) = howMany;
        
        // Compute the force as a function of distance
        int i;
        double r, ratio, scale;
        for (i=0;i<howMany;i++) {
            r = i*dr;
            // Compute the expression
            ratio = r/R0;
            scale = overallScale*(1.0/((1-ratio)*(1-ratio)) - 1.0 + 4*ratio); // Includes the normal
            forcePlot(0,i+1) = r;
            forcePlot(1,i+1) = scale;
        }
        
        DTPlot1D theForce(forcePlot);
        WriteOne(outputFile,"LoopForce",theForce);
    }
}

#pragma mark Functions


DTPath3D ConvertToPath(const DTMutableList<SingleSegment> &chains)
{
    DTMutableDoubleArray loops(3,100);
    int posInLoops = 0;
    int i,numP,Nc = chains.Length();
    DTPointCollection3D points;
    
    for (i=0;i<Nc;i++) {
        points = chains(i).xyLocations;
        numP = points.NumberOfPoints();
        if (loops.n()<posInLoops+1+numP) {
            loops = IncreaseSize(loops,loops.Length() + 3*numP);
        }
        loops(0,posInLoops) = 0;
        loops(1,posInLoops) = 0;
        loops(2,posInLoops) = numP;
        posInLoops++;
        MemoryCopyColumns(loops,posInLoops,points.DoubleData(),DTRange(0,numP));
        posInLoops+=numP;
    }
    
    loops = TruncateSize(loops,3*posInLoops);
    return DTPath3D(loops);
}

DTPath3D LoopSegments(const DTMutableList<SingleSegment> &chains)
{
    DTMutableDoubleArray loops(3,100);
    int posInLoops = 0;
    int i,j,from,to,numP,Nc = chains.Length();
    DTPointCollection3D points;
    DTDoubleArray xy;
    DTIntArray loopFromChain;
    
    // Create a polygon which is a collection of single line segments.
    // The polygon is encoded to save all of the segments into a single path (see DTPath3D.h).
    for (i=0;i<Nc;i++) {
        loopFromChain = chains(i).loops;
        points = chains(i).xyLocations;
        xy = points.DoubleData();
        numP = loopFromChain.n();
        if (loops.n()<posInLoops+3*numP) {
            loops = IncreaseSize(loops,loops.Length() + 3*numP);
        }
        for (j=0;j<numP;j++) {
            loops(0,posInLoops) = 0;
            loops(1,posInLoops) = 0;
            loops(2,posInLoops) = 2;
            posInLoops++;
            
            from = loopFromChain(0,j);
            to = loopFromChain(1,j);
            
            loops(0,posInLoops) = xy(0,from);
            loops(1,posInLoops) = xy(1,from);
            loops(2,posInLoops) = xy(2,from);
            posInLoops++;
            
            loops(0,posInLoops) = xy(0,to);
            loops(1,posInLoops) = xy(1,to);
            loops(2,posInLoops) = xy(2,to);
            posInLoops++;
        }
    }
    
    loops = TruncateSize(loops,3*posInLoops);
    return DTPath3D(loops);
}

DTIntArray ComputeLoopConnectionsOffset(DTList<SingleSegment> &segments)
{
    // Need to be able to extract the segments that connect the loops
    
    int i,howMany,k,Nc = segments.Length();
    SingleSegment segment;
    DTPointCollection3D xy;
    DTIntArray loops;
    DTMutableIntArray returnLoops(100);
    int posInReturn = 0;
    int from, to, chain;
    
    DTMutableIntArray startOfChain(Nc);
    int pointsSoFar = 0;
    for (k=0;k<Nc;k++) {
        startOfChain(k) = pointsSoFar;
        pointsSoFar += segments(k).xyLocations.NumberOfPoints();
    }

    pointsSoFar = 0;
    for (k=0;k<Nc;k++) {
        segment = segments(k);
        howMany = segment.howManyLoops;
        if (howMany==0) continue;
        
        xy = segment.xyLocations;
        loops = segment.loops;
        
        // loop connectors
        if (posInReturn+3*howMany>returnLoops.Length()) returnLoops = IncreaseSize(returnLoops,returnLoops.Length()+3*howMany);
        
        if (loops.m()==3) {
            // from, to, segment for to.  But make sure that I'm not including the segment twice
            for (i=0;i<howMany;i++) {
                from = loops(0,i); // On chain k
                to = loops(1,i);
                chain = loops(2,i);
                
                // Use dictionary sort, first sort by segment, then by connection
                if (k<chain || (k==chain && from<to)) {
                    returnLoops(posInReturn++) = 2;
                    returnLoops(posInReturn++) = loops(0,i)+startOfChain(k);
                    returnLoops(posInReturn++) = loops(1,i)+startOfChain(chain);
                }
            }
        }
        else {
            for (i=0;i<howMany;i++) {
                returnLoops(posInReturn++) = 2;
                returnLoops(posInReturn++) = loops(0,i)+startOfChain(k);
                returnLoops(posInReturn++) = loops(1,i)+startOfChain(k);
            }
        }
        
        // Backbone
        
        // lengthSoFar += 1 + xy.NumberOfPoints();
        // pointsSoFar += xy.NumberOfPoints();
    }
    
    returnLoops = TruncateSize(returnLoops,posInReturn);
    
    return returnLoops;
}

DTIntArray ComputeOnMarkers(DTList<SingleSegment> &segments)
{
    // Need to be able to extract the segments that connect the loops
    
    int k,Nc = segments.Length();
    SingleSegment segment;
    
    DTIntArray toReturn,fromSegment;
    
    for (k=0;k<Nc;k++) {
        segment = segments(k);
        fromSegment = segment.OnMarkers();
        if (fromSegment.NotEmpty()) {
            toReturn = CombineRows(toReturn,fromSegment);
        }
    }
    
    return toReturn;
}

DTIntArray ComputeOffMarkers(DTList<SingleSegment> &segments)
{
    // Need to be able to extract the segments that connect the loops
    
    int k,Nc = segments.Length();
    SingleSegment segment;
    
    DTIntArray toReturn,fromSegment;
    
    for (k=0;k<Nc;k++) {
        segment = segments(k);
        fromSegment = segment.OffMarkers();
        if (fromSegment.NotEmpty()) {
            toReturn = CombineRows(toReturn,fromSegment);
        }
    }

    return toReturn;
}

void SaveLoopConnectionsOffset(DTList<SingleSegment> &segments,DTMatlabDataFile &outputFile)
{
    // Need to be able to extract the segments that connect the loops
    
    DTIntArray returnLoops = ComputeLoopConnectionsOffset(segments);
    
    int k,Nc = segments.Length();
    SingleSegment segment;
    
    DTMutableDictionary parametersToSave;
    DTMutableDictionary temp;
    
    for (k=0;k<Nc;k++) {
        segment = segments(k);
        parametersToSave("Chain "+DTInt2String(k+1)) = segment.StructureInfo();
    }
    
    WriteOne(outputFile,"LoopConnectors",returnLoops);
    WriteOne(outputFile,"LoopInformation", parametersToSave);
    
    // Now create the segmentNumber and beadInSegment lists
    int howManyPointsSoFar = 0;
    int howManyPointsHere;
    for (k=0;k<Nc;k++) {
        howManyPointsHere = segments(k).NumberOfPoints();
        howManyPointsSoFar+=howManyPointsHere;
    }
    DTMutableIntArray segmentNumber(howManyPointsSoFar);
    DTMutableIntArray beadInSegment(howManyPointsSoFar);
    int index,ptN = 0;
    for (k=0;k<Nc;k++) {
        // Two segments, and their length depends on the number of base pairs
        howManyPointsHere = segments(k).NumberOfPoints();
        for (index=0;index<howManyPointsHere;index++) {
            segmentNumber(ptN) = 2*k;
            beadInSegment(ptN) = index;
            ptN++;
        }
    }
    WriteOne(outputFile,"segmentNumber",segmentNumber);
    WriteOne(outputFile,"beadInSegment",beadInSegment);
}

void AddDynamicLoops(DTMutableList<SingleSegment> &segmentList,const DTDictionary &terms,double t,double dt)
{
    int k, Nc = segmentList.Length();
    
    // The update mechanism is global, since loops might happen between arms.
    
    // Rule here is as follows.  If automaticLoopConnected(i)==-1 and automaticLoopTag(i)==1 this marker
    // is ready for a connection but not connected yet.  This is inside each segment
    
    
    DTDictionary autoInformation = terms("auto looping");
    double automaticLoopsStartAt = autoInformation("start");
    
    if (t<automaticLoopsStartAt) {
        // Looping not started yet
        return;
    }
    
    double automaticLoopMeanTimeOn = autoInformation("mean on");
    double automaticLoopSigmaTimeOn = autoInformation("std on");
    double automaticLoopMeanTimeOff = autoInformation("mean off");
    double automaticLoopSigmaTimeOff = autoInformation("std off");
    
    if (autoInformation.Contains("timeChange") &&  t>autoInformation("timeChange")) {
        double scaleBy = autoInformation("changeBy");
        automaticLoopMeanTimeOn /= scaleBy;
        automaticLoopSigmaTimeOn /= scaleBy;
        automaticLoopMeanTimeOff /= scaleBy;
        automaticLoopSigmaTimeOff /= scaleBy;
    }
    
    // automaticOnPropability = terms("auto probability");
    double automaticDistanceBarrier = autoInformation("barrier");
    
    int i,howMany;
    // int i,howMany = automaticLoopingRange.length;
    
    static bool initialSeedDone = false;
    
    // DTRange automaticLoopingRange;
    DTMutableCharArray automaticLoopTag;
    DTMutableDoubleArray automaticLoopTrigger;
    DTMutableIntArray automaticLoopConnected;
    DTMutableIntArray otherAutomaticLoopConnected;
    // DTMutableIntArray automaticLoopWorkList;
    DTIntArray pointsThatCanBeLooped;
    
    if (initialSeedDone==false) {
        initialSeedDone = true;
        // Initially spread the expiration points uniformly.  If p = percentage on at any given time
        
        double timeInCycle;
        double cycleTime = automaticLoopMeanTimeOn+automaticLoopMeanTimeOff;
        double automaticOnPropability = automaticLoopMeanTimeOn/cycleTime;
        
        // Go over all of the segments and set the tag and trigger variables
        
        
        for (k=0;k<Nc;k++) {
            // automaticLoopingRange = segmentList(k).automaticLoopingRangeOld;
            
            // howMany = automaticLoopingRange.length;
            howMany = segmentList(k).pointsThatCanBeLooped.Length();
            
            if (howMany==0) continue;
            
            DTRandom &automaticRandom = segmentList(k).automaticRandom;
            automaticLoopTag = segmentList(k).automaticLoopTag;
            automaticLoopTrigger = segmentList(k).automaticLoopTrigger;
            
            for (i=0;i<howMany;i++) {
                // Initially spread the expiration points uniformly.  If p = percentage on at any given time
                timeInCycle = automaticRandom.UniformHalf()*cycleTime;
                if (timeInCycle<automaticLoopMeanTimeOn) {
                    // Considered on
                    automaticLoopTag(i) = 1;
                    automaticLoopTrigger(i) = automaticLoopsStartAt+timeInCycle;
                }
                else {
                    // Off
                    automaticLoopTag(i) = 0;
                    automaticLoopTrigger(i) = automaticLoopsStartAt+timeInCycle - cycleTime*automaticOnPropability;
                }
            }
        }
    }
    
    // Step 1: go over the beads and see which one should be disconnected.  If so, compute the time it should reconnect.
    // Step 2: go over the beads and see which points should be set up for connection.  If so, compute the time it should disconnect
    // Step 3: Go over the points that are not connected but should be and see if they are within the radius of connection
    //         If so make the connection from the smallest to the largest distance.
    // Step 4: Remake the loop data structure so that the force calculation will work
    
    bool loopsMightChange = false;
    
    // ************************************
    // Step 1:  Check if a connecting breaks.
    for (k=0;k<Nc;k++) {
        // automaticLoopingRange = segmentList(k).automaticLoopingRangeOld;
        // howMany = automaticLoopingRange.length;
        
        howMany = segmentList(k).pointsThatCanBeLooped.Length();
        
        if (howMany==0) continue;
        
        DTRandom &automaticRandom = segmentList(k).automaticRandom;
        automaticLoopTag = segmentList(k).automaticLoopTag;
        automaticLoopTrigger = segmentList(k).automaticLoopTrigger;
        automaticLoopConnected = segmentList(k).automaticLoopConnected;
        
        for (i=0;i<howMany;i++) {
            if (automaticLoopTag(i)==1 && automaticLoopTrigger(i)<=t) {
                automaticLoopTag(i) = 0;
                // Compute a new on time
                automaticLoopTrigger(i) += automaticRandom.Normal(automaticLoopMeanTimeOff,automaticLoopSigmaTimeOff);
                if (automaticLoopConnected(0,i)>=0) {
                    // This point was part of a loop, needs to be disconnected
                    // automaticLoopConnected(automaticLoopConnected(i)) = -1;
                    otherAutomaticLoopConnected = segmentList(automaticLoopConnected(0,i)).automaticLoopConnected;
                    otherAutomaticLoopConnected(0,automaticLoopConnected(1,i)) = -1;
                    otherAutomaticLoopConnected(1,automaticLoopConnected(1,i)) = -1;
                    // automaticLoopConnected(i) = -1;
                    automaticLoopConnected(0,i) = -1;
                    automaticLoopConnected(1,i) = -1;
                    loopsMightChange = true;
                }
            }
        }
    }
    
    // ************************************
    // Step 2: See if a point becomes active
    for (k=0;k<Nc;k++) {
        howMany = segmentList(k).pointsThatCanBeLooped.Length();
        
        // automaticLoopingRange = segmentList(k).automaticLoopingRangeOld;
        // howMany = automaticLoopingRange.length;
        
        if (howMany==0) continue;
        
        DTRandom &automaticRandom = segmentList(k).automaticRandom;
        automaticLoopTag = segmentList(k).automaticLoopTag;
        automaticLoopTrigger = segmentList(k).automaticLoopTrigger;
        
        for (i=0;i<howMany;i++) {
            if (automaticLoopTag(i)==0 && automaticLoopTrigger(i)<=t) {
                automaticLoopTag(i) = 1;
                // Compute a new off time.  There is a tiny chance that this will be before the current time but that will be addressed in the next time step
                automaticLoopTrigger(i) += automaticRandom.Normal(automaticLoopMeanTimeOn,automaticLoopSigmaTimeOn);
            }
        }
    }
    
    // ************************************
    // Step 3:  Go over points that are not connected
    static DTMutableIntArray workLocationArray;
    static DTMutableDoubleArray workPointArray;
    static DTMutableDoubleArray workMatrix;
    if (workLocationArray.Length()==0) {
        workLocationArray = DTMutableIntArray(2,3000);
        workPointArray = DTMutableDoubleArray(3,3000);
        workMatrix = DTMutableDoubleArray(100,100);
    }
    
    DTDoubleArray xy;
    int howManyPoints = 0;
    int ptN;
    for (k=0;k<Nc;k++) {
        pointsThatCanBeLooped = segmentList(k).pointsThatCanBeLooped;
        howMany = pointsThatCanBeLooped.Length();
        
        // automaticLoopingRange = segmentList(k).automaticLoopingRangeOld;
        // howMany = automaticLoopingRange.length;
        
        if (howMany==0) continue;
        
        automaticLoopTag = segmentList(k).automaticLoopTag;
        automaticLoopConnected = segmentList(k).automaticLoopConnected;
        xy = segmentList(k).xyLocations.DoubleData();
        // automaticLoopWorkList = segmentList(k).automaticLoopWorkList;
        
        for (i=0;i<howMany;i++) {
            if (automaticLoopConnected(0,i)==-1 && automaticLoopTag(i)==1) {
                // automaticLoopWorkList(howManyPoints++) = i;
                workLocationArray(0,howManyPoints) = k;
                workLocationArray(1,howManyPoints) = i;
                // ptN = i+automaticLoopingRange.start;
                ptN = pointsThatCanBeLooped(i);
                workPointArray(0,howManyPoints) = xy(0,ptN);
                workPointArray(1,howManyPoints) = xy(1,ptN);
                workPointArray(2,howManyPoints) = xy(2,ptN);
                howManyPoints++;
            }
        }
    }
    
    if (howManyPoints>workMatrix.m()) {
        workMatrix = DTMutableDoubleArray(howManyPoints+50,howManyPoints+50);
    }
    double *workMatrixD = workMatrix.Pointer();
    int workM = workMatrix.m();
    
    // Now use the howManyPoints x howManyPoints block in automaticLoopWorkMatrix and compute the lengths.
    int j;
    double x1,y1,z1;
    double x2,y2,z2;
    double dx,dy,dz;
    double distance;
    for (i=1;i<howManyPoints;i++) {
        // pt1 = automaticLoopWorkList(i)+automaticLoopingRange.start;
        x1 = workPointArray(0,i);
        y1 = workPointArray(1,i);
        z1 = workPointArray(2,i);
        for (j=0;j<i;j++) {
            x2 = workPointArray(0,j);
            y2 = workPointArray(1,j);
            z2 = workPointArray(2,j);
            dx = x1-x2;
            dy = y1-y2;
            dz = z1-z2;
            distance = sqrt(dx*dx+dy*dy+dz*dz);
            workMatrix(i,j) = distance;
        }
    }
    
    int smallestI,smallestJ;
    double smallestValue;
    while (1) {
        smallestI = 0;
        smallestJ = 0;
        smallestValue = automaticDistanceBarrier;
        
        for (i=0;i<howManyPoints;i++) {
            for (j=0;j<i;j++) {
                // if (workMatrix(i,j)<smallestValue) {
                if (workMatrixD[i+j*workM]<smallestValue) {
                    smallestI = i;
                    smallestJ = j;
                    smallestValue = workMatrix(i,j);
                }
            }
        }
        if (smallestValue==automaticDistanceBarrier) {
            // Nothing smaller, so no more connections made
            break;
        }
        
        loopsMightChange = true;
        
        // Change things so that they won't be connected to anything else.
        i = smallestI;
        for (j=0;j<i;j++) workMatrix(i,j) = automaticDistanceBarrier;
        i = smallestJ;
        for (j=0;j<i;j++) workMatrix(i,j) = automaticDistanceBarrier;
        j = smallestI;
        for (i=j+1;i<howManyPoints;i++) workMatrix(i,j) = automaticDistanceBarrier;
        j = smallestJ;
        for (i=j+1;i<howManyPoints;i++) workMatrix(i,j) = automaticDistanceBarrier;
        
        // Tie together beads smallestI and smallestJ.
        
        // smallestI should point to smallestJ
        k = workLocationArray(0,smallestI); // First figure out where smallestI really is in the list
        i = workLocationArray(1,smallestI);
        if (segmentList(k).automaticLoopConnected(0,i)>=0) DTErrorMessage("Should not happen");
        segmentList(k).automaticLoopConnected(0,i) = workLocationArray(0,smallestJ);
        segmentList(k).automaticLoopConnected(1,i) = workLocationArray(1,smallestJ);
        
        // smallestJ should point to smallestI
        k = workLocationArray(0,smallestJ); // First figure out where smallestI really is in the list
        i = workLocationArray(1,smallestJ);
        if (segmentList(k).automaticLoopConnected(0,i)>=0) DTErrorMessage("Should not happen");
        segmentList(k).automaticLoopConnected(0,i) = workLocationArray(0,smallestI);
        segmentList(k).automaticLoopConnected(1,i) = workLocationArray(1,smallestI);
    }
    
    // ************************************
    // Step 4:
    // Now create the loops.
    DTMutableIntArray loops;
    int howManyLoops;
    if (loopsMightChange) {
        for (k=0;k<Nc;k++) {
            // automaticLoopingRange = segmentList(k).automaticLoopingRangeOld;
            // howMany = automaticLoopingRange.length;
            
            pointsThatCanBeLooped = segmentList(k).pointsThatCanBeLooped;
            howMany = pointsThatCanBeLooped.Length();
            
            if (howMany==0) continue;
            
            automaticLoopConnected = segmentList(k).automaticLoopConnected;
            segmentList(k).howManyLoops = 0;
            loops = segmentList(k).loops;
            howManyLoops = 0;
            
            for (i=0;i<howMany;i++) {
                if (automaticLoopConnected(0,i)>=0) {
                    // This point is connected to a second point that is earlier in the list
                    // For bridging loops, this is a 3xK array.  (0,k) is a bead # here, (1,k) is the second bead and (2,k) is the arm for that bead
                    // loops(0,howManyLoops) = i+automaticLoopingRange.start;
                    loops(0,howManyLoops) = pointsThatCanBeLooped(i);
                    // loops(1,howManyLoops) = segmentList(automaticLoopConnected(0,i)).automaticLoopingRangeOld.start + automaticLoopConnected(1,i);
                    loops(1,howManyLoops) = segmentList(automaticLoopConnected(0,i)).pointsThatCanBeLooped(automaticLoopConnected(1,i));
                    loops(2,howManyLoops) = automaticLoopConnected(0,i);
                    howManyLoops++;
                }
            }
            
            segmentList(k).howManyLoops = howManyLoops;
            
            /*
             for (i=0;i<howMany;i++) {
             if (automaticLoopConnected(i)>=0 && automaticLoopConnected(i)<i) {
             // This point is connected to a second point that is earlier in the list
             loops(0,howManyLoops) = automaticLoopConnected(i)+automaticLoopingRange.start; // The position in the xy list for this segment.
             loops(1,howManyLoops) = i+automaticLoopingRange.start;
             howManyLoops++;
             }
             }
             */
        }
    }
    
    
    for (k=0;k<Nc;k++) segmentList(k).AddLoopAttraction(segmentList,t,dt);
}

void AddToSumOfAllPairwiseDistances(DTMutableList<SingleSegment> &segmentList,DTMutableDoubleArray sumOfAllPairwiseDistances)
{
    //
}

