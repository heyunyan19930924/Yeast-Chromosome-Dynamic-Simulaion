// #include "DTSource.h"
#include "DTSaveError.h"

#include "DTArguments.h"
#include "DTDictionary.h"
#include "DTDoubleArray.h"
#include "DTMatlabDataFile.h"
#include "DTPath3D.h"
#include "DTPointCollection3D.h"
#include "DTProgress.h"
#include "DTSeriesPath3D.h"
#include "DTSeriesPointCollection3D.h"
#include "DTPlot1D.h"
#include "DTCharArray.h"
#include "DTSeriesNumberList.h"

//////////////////////////////////////////////////////////////////////////////
//    Main routine
//////////////////////////////////////////////////////////////////////////////

void Computation(const DTDictionary &coefficients,const DTDictionary &terms,
                 const DTDictionary &evolution,const DTPointCollection3D &ends,
                 const DTDoubleArray &lengths,const DTDoubleArray &startIndex,
                 const DTDoubleArray &endIndex,int seed,
                 DTSeriesPath3D &computed,
                 DTMatlabDataFile &outputFile);

int main(int argc,const char *argv[])
{
    DTSetArguments(argc,argv);
    
    DTMatlabDataFile inputFile("Input.mat",DTFile::ReadOnly);
    DTMatlabDataFile outputFile("Output.mat",DTFile::NewReadWrite);
    
    // Input variables.
    DTDictionary coefficients;
    Read(inputFile,"coefficients",coefficients);
    DTDictionary terms;
    Read(inputFile,"terms",terms);
    DTDictionary evolution;
    Read(inputFile,"evolution",evolution);
    DTPointCollection3D ends;
    Read(inputFile,"ends",ends);
    DTDoubleArray lengths = inputFile.ReadDoubleArray("lengths");
    DTDoubleArray startIndex = inputFile.ReadDoubleArray("startIndex");
    DTDoubleArray endIndex = inputFile.ReadDoubleArray("endIndex");
    int seed = int(inputFile.ReadNumber("seed"));
    
    // Output series.
    DTSeriesPath3D computed(outputFile,"Var");
    computed.SetShouldSaveDoubleAsFloat();
    
    if (DTArgumentIncludesFlag("saveInput")) { // Enable to save the input in the output file.
        WriteOne(outputFile,"coefficients",coefficients);
        WriteOne(outputFile,"terms",terms);
        WriteOne(outputFile,"evolution",evolution);
        WriteOne(outputFile,"ends",ends);
        WriteOne(outputFile,"lengths",lengths);
        WriteOne(outputFile,"startIndex",startIndex);
        WriteOne(outputFile,"endIndex",endIndex);
        WriteOne(outputFile,"seed",seed);
    }
    
    // The computation.
    clock_t t_before = clock();
    Computation(coefficients,terms,evolution,ends,lengths,startIndex,endIndex,seed,computed,outputFile);
    clock_t t_after = clock();
    double exec_time = double(t_after-t_before)/double(CLOCKS_PER_SEC);
    
    // The execution time.
    outputFile.Save(exec_time,"ExecutionTime");
    outputFile.Save("Real Number","Seq_ExecutionTime");
    
    // The errors.
    DTSaveError(outputFile,"ExecutionErrors");
    outputFile.Save("StringList","Seq_ExecutionErrors");
    
    outputFile.SaveIndex();
    
    return 0;
}

//////////////////////////////////////////////////////////////////////////////
//    Computational routine
//////////////////////////////////////////////////////////////////////////////

#include "SingleSegment.h"

#include "DTDoubleArrayOperators.h"
#include "DTVectorCollection2D.h"
#include "DTPoint2D.h"
#include "DTProgress.h"
#include "DTRandom.h"
#include "DTUtilities.h"

void Computation(const DTDictionary &coefficients,const DTDictionary &terms,
                 const DTDictionary &evolution,const DTPointCollection3D &ends,
                 const DTDoubleArray &lengths,const DTDoubleArray &startIndex,
                 const DTDoubleArray &endIndex,int seed,
                 DTSeriesPath3D &computed,
                 DTMatlabDataFile &outputFile)
{
    /*
    // Remove, and change terms back to const &
    DTMutableDictionary termC = terms.Copy();
    DTMutableDictionary aut = ((DTDictionary)termC("auto looping")).Copy();
    aut("start") = 0.01;
    termC("auto looping") = aut;
    terms = termC;
    */
    
    DTSeriesNumberList savedLoops(outputFile,"Loops");
    DTIntArray lastLoopSaved,currentLoop;
    DTIntArray lastMarkersOn,lastMarkersOff;
    DTSeriesNumberList savedOnMarkersOn(outputFile,"MarkersOn");
    DTSeriesNumberList savedOnMarkersOff(outputFile,"MarkersOff");
    
    double radius = coefficients("radius"); // mean radious of nucleus wall

    double dt = evolution("dt");
    // DEBUG: dt = 0.0001
    double until = evolution("until");
    
    // Remove
    // until = 0.15;
    
    double save = evolution("save");
    double startSaving = evolution.GetNumber("startSaving", 0.0);
    bool excludedVolume = terms("excludedVolume");
    bool noiseTerm = terms("noiseTerm");
    bool springTerm = terms("springTerm");
    
    bool accumulateStatistics = terms.Contains("accumulateStatistics");
    DTDictionary accumulativeStatisticsInfo;
    if (accumulateStatistics) {
        accumulativeStatisticsInfo = terms("accumulateStatistics");
    }
    // bool confine = terms("confine");
    int loopType = terms("loops");
    
    DTRandom random(seed);
    
    int Nc = 2*lengths.n();

    DTMutableList<SingleSegment> segmentList(Nc);

    //DTMutableList<DTMutablePointCollection3D> xyLocations(Nc); // x and y coordinates together
    //DTMutableList<DTPointCollection3D> referenceLocations(Nc); // x and y coordinates together
    //DTMutableList<DTMutablePointCollection3D> Relative(Nc); // x and y coordinates together

    // Initial configuration
    int k;
    DTMutableDoubleArray pointLocations,directionValues;
    int howManyPointsSoFar = 0;
    
    for (k=0;k<lengths.n();k++) {
        // Two segments, and their length depends on the number of base pairs
        segmentList(2*k) = SingleSegment(2*k,howManyPointsSoFar,DTPoint3D(0,0,radius),radius*ends(startIndex(k)),lengths(1,k),coefficients,terms);
        howManyPointsSoFar += segmentList(2*k).NumberOfPoints();
        
        // The second part
        segmentList(2*k+1) = SingleSegment(2*k+1,howManyPointsSoFar,DTPoint3D(0,0,radius),radius*ends(endIndex(k)),lengths(0,k) - lengths(1,k),coefficients,terms);
        howManyPointsSoFar += segmentList(2*k+1).NumberOfPoints();
    }
    
    
    // Accumulative statistics, if turned on.
    DTMutableDoubleArray sumOfAllPairwiseDistances;
    if (accumulateStatistics) {
        if (accumulativeStatisticsInfo("pairwise distances")) {
            sumOfAllPairwiseDistances = DTMutableDoubleArray(howManyPointsSoFar,howManyPointsSoFar);
            sumOfAllPairwiseDistances = 0.0;
        }
    }
    
    // Save some structural information into the output file.
    SaveLoopConnectionsOffset(segmentList,outputFile);
    
    // Save information about the excluded volume that I'm using
    segmentList(0).SaveInformationToFile(outputFile);
    for (k=0;k<Nc;k++) {
        // Save debug information for the automatic loop.
        segmentList(k).SaveInformationForSegment(outputFile);
    }
    outputFile.Flush();

    int maxLength = 0;
    for (k=0;k<Nc;k++) {
        maxLength = std::max(maxLength,segmentList(k).NumberOfPoints());
    }

    DTMutableDoubleArray forceArray(3,maxLength+3);
    
    DTDoubleArray xyCoordsInside, xy;
    DTMutableDoubleArray updateArray, canChange;

    // drag = 6*pi*eta*A
    // eta = viscosity 10^-8 pNs/(nm)^2
    // drag = A = radius of bead = 10nm

    // double sqrtDTOverN = sqrt(dt)/sqrt(2*(N+1)); - Before April
    // double drag = 6*M_PI*eta*beadR; - Before April
    // double drag = zetaEff;
    // double C1 = -3/(8*L_p*L_p*d*d); - Before April

    // double k_s = 3*K_bT/(4*L_p*L_p); - Before April
    
    DTMutablePointCollection3D converted;


    double t = 0.0;
    // Save the initial state if you start saving at t=0.
    // The position of the beads as well as the loops and what segments are active/inactive for dynamic looping.
    if (t>=startSaving) {
        computed.Add(ConvertToPath(segmentList),t);
        currentLoop = ComputeLoopConnectionsOffset(segmentList);
        if (currentLoop!=lastLoopSaved) {
            savedLoops.Add(currentLoop,t);
            lastLoopSaved = currentLoop;
        }
        currentLoop = ComputeOnMarkers(segmentList);
        if (currentLoop!=lastMarkersOn) {
            savedOnMarkersOn.Add(currentLoop,t);
            lastMarkersOn = currentLoop;
        }
        currentLoop = ComputeOffMarkers(segmentList);
        if (currentLoop!=lastMarkersOff) {
            savedOnMarkersOff.Add(currentLoop,t);
            lastMarkersOff = currentLoop;
        }
    }
    
    int saveStride = int(save);
    
    DTProgress progress;
    
    DTMutableDoubleArray randomNoise(3,maxLength);
    
    int timeStep = 0;

    double noiseOffAt = terms.GetNumber("noiseOffAt",INFINITY);
    

    while (t<until) {
        timeStep++;
        
        progress.UpdatePercentage(t/until);
        
        // Compute F(Y), using notation in SingleSegment
        for (k=0;k<Nc;k++) {
            segmentList(k).updates.DoubleData() = 0.0; // Sets Fk = 0
        }
        
        // ********************************************************************************
        // Excluded volume
        // segmentList is really the Y state
        if (excludedVolume) {
            for (k=0;k<Nc;k++) segmentList(k).ExcludedVolumeTerm(segmentList,dt); // Fk += dt * excluded volume.
        }

        // Forces
        if (springTerm) {
            for (k=0;k<Nc;k++) segmentList(k).SpringTerm(t,dt,forceArray);
        }
        
        // Compute noise
        if (noiseTerm && t<noiseOffAt) {
            for (k=0;k<Nc;k++) segmentList(k).AddNoise(random,dt,randomNoise);
        }

        // Adds loops and computes their contribution.
        if (loopType>0) {
            if (loopType==4) {
                AddDynamicLoops(segmentList,terms,t,dt);
            }
            else {
                for (k=0;k<Nc;k++) segmentList(k).AddLoopAttraction(t,dt);
            }
        }

        // ********************************************************************************
        // Now apply the update to the locations, this is Y_{n+1} = Y_{n} + dt*F(Y_{n})
        // Where dt*F(Y_n) is what is stored in the update list
        for (k=0;k<Nc;k++) {
            segmentList(k).xyLocations += segmentList(k).updates;
        }
        
        // ********************************************************************************
        // Confinement
        for (k=0;k<Nc;k++) segmentList(k).Confine(t);
        
        t += dt;
        
        if (timeStep%saveStride==0) {
            if (t>=startSaving) {
                computed.Add(ConvertToPath(segmentList),t);
                currentLoop = ComputeLoopConnectionsOffset(segmentList);
                if (currentLoop!=lastLoopSaved) {
                    savedLoops.Add(currentLoop,t);
                    lastLoopSaved = currentLoop;
                }
                currentLoop = ComputeOnMarkers(segmentList);
                if (currentLoop!=lastMarkersOn) {
                    savedOnMarkersOn.Add(currentLoop,t);
                    lastMarkersOn = currentLoop;
                }
                currentLoop = ComputeOffMarkers(segmentList);
                if (currentLoop!=lastMarkersOff) {
                    savedOnMarkersOff.Add(currentLoop,t);
                    lastMarkersOff = currentLoop;
                }
            }
        }
        
        // Save state?
        
        // Accumulative statistics
        if (accumulateStatistics) {
            if (accumulativeStatisticsInfo("pairwise distances")) {
                AddToSumOfAllPairwiseDistances(segmentList,sumOfAllPairwiseDistances);
            }
        }
    }
}

