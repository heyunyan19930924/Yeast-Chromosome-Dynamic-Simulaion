// Include DTSource.h if you want to include all the headers.

#include "DTArguments.h"
#include "DTSaveError.h"

#include "DTDataFile.h"
#include "DTMesh3D.h"
#include "DTPointCollection3D.h"
#include "DTRegion3D.h"

// Common utilities
#include "DTDoubleArrayOperators.h"
#include "DTProgress.h"
#include "DTTimer.h"
#include "DTUtilities.h"
#include "DTDictionary.h"

#include <math.h>

DTMesh3D Computation(const DTPointCollection3D &points,const DTRegion3D &bbox,const DTMesh3D &element);

int main(int argc,const char *argv[])
{
    DTSetArguments(argc,argv);
    
    DTDataFile inputFile("Input.dtbin",DTFile::ReadOnly);
    // Read in the input variables.
    DTPointCollection3D points;
    Read(inputFile,"points",points);
    DTRegion3D bbox;
    Read(inputFile,"bbox",bbox);
    DTMesh3D element;
    Read(inputFile,"element",element);
    
    // The computation.
    DTMesh3D computed;
    clock_t t_before = clock();
    computed = Computation(points,bbox,element);
    clock_t t_after = clock();
    double exec_time = double(t_after-t_before)/double(CLOCKS_PER_SEC);
    
    // Write the output.
    DTDataFile outputFile("Output.dtbin",DTFile::NewReadWrite);
    
    // Output from computation
    Write(outputFile,"Var",computed);
    outputFile.Save("Mesh3D","Seq_Var");
    
    // The execution time.
    outputFile.Save(exec_time,"ExecutionTime");
    outputFile.Save("Real Number","Seq_ExecutionTime");
    
    // The errors.
    DTSaveError(outputFile,"ExecutionErrors");
    outputFile.Save("StringList","Seq_ExecutionErrors");
    
    return 0;
}

DTMesh3D Computation(const DTPointCollection3D &points,const DTRegion3D &bbox,const DTMesh3D &element)
{
    DTMesh3DGrid grid = element.Grid();
    DTPoint3D gridOrigin = grid.Origin();
    DTPoint3D bottom = bbox.Minimum();
    DTPoint3D top = bbox.Maximum();
    DTPoint3D newOrigin(gridOrigin.x + ceil((bottom.x-gridOrigin.x)/grid.dx())*grid.dx(),
                        gridOrigin.y + ceil((bottom.y-gridOrigin.y)/grid.dy())*grid.dy(),
                        gridOrigin.z + ceil((bottom.z-gridOrigin.z)/grid.dz())*grid.dz());
    int m = floor((top.x-newOrigin.x)/grid.dx())+1;
    int n = floor((top.y-newOrigin.y)/grid.dy())+1;
    int o = floor((top.z-newOrigin.z)/grid.dz())+1;
    
    DTMesh3DGrid newGrid(newOrigin,grid.dx(),grid.dy(),grid.dz(),m,n,o);
    
    DTFloatArray generator = ConvertToFloat(element).FloatData();
    int genM = generator.m();
    int genN = generator.n();
    int genO = generator.o();
    
    // Find the maximum point
    int ijk, mno = genM*genN*genO;
    float maxSoFar = generator(0);
    int maxAt = 0;
    for (ijk=1;ijk<mno;ijk++) {
        if (maxSoFar<generator(ijk)) {
            maxAt = ijk;
            maxSoFar = generator(ijk);
        }
    }
    DTPoint3D centerInGrid = DTPoint3D(maxAt%genM,(maxAt/genM)%genN,maxAt/(genM*genN));
    // DTPoint3D centerInGridComp = grid.ConvertCoordinateToGrid(center);
    
    DTMutableFloatArray toReturn(m,n,o);
    toReturn = 0.0;
    
    int ptN, howManyPoints = points.NumberOfPoints();
    DTPoint3D P;
    DTPoint3D bottomForGenerator;
    int iBottom,jBottom,kBottom;
    int iMin,iMax,jMin,jMax,kMin,kMax,i,j,k;
    float *toReturnD = toReturn.Pointer();
    float *returnShifted;
    const float *generatorD = generator.Pointer();
    const float *generatorShifted;
    int mn = m*n;
    int genMN = genM*genN;
    int shiftReturn;
    int shiftGenerator;
    
    for (ptN=0;ptN<howManyPoints;ptN++) {
        P = points(ptN); // Physical coordinates
        P = newGrid.ConvertCoordinateToGrid(P); // In pixel coordinates
        
        // This is the coordinate of where I want to map the center
        bottomForGenerator = P-centerInGrid;
        // Round this to the nearest integer
        iBottom = int(round(bottomForGenerator.x));
        jBottom = int(round(bottomForGenerator.y));
        kBottom = int(round(bottomForGenerator.z));
        
        // Need to compute
        // combined(iBottom+i,...) += generator(i,...)
        iMin = std::max(0,-iBottom); // iBottom+i>=0
        jMin = std::max(0,-jBottom);
        kMin = std::max(0,-kBottom);
        iMax = std::min(genM,m-iBottom); // iBottom+iMax=m
        jMax = std::min(genN,n-jBottom);
        kMax = std::min(genO,o-kBottom);
        for (k=kMin;k<kMax;k++) {
            for (j=jMin;j<jMax;j++) {
                shiftReturn = iBottom+(jBottom+j)*m+(kBottom+k)*mn;
                shiftGenerator = j*genM+k*genMN;
                returnShifted = toReturnD+shiftReturn;
                generatorShifted = generatorD+shiftGenerator;
                for (i=iMin;i<iMax;i++) {
                    // toReturn(iBottom+i,jBottom+j,kBottom+k) += generator(i,j,k);
                    // toReturn(iBottom+i+(jBottom+j)*m+(kBottom+k)*mn) += generator(i+j*genM+k*genMN);
                    // toReturnD[shiftReturn+i] += generatorD[i+shiftGenerator];
                    returnShifted[i] += generatorShifted[i];
                }
            }
        }
    }
    
    return DTMesh3D(newGrid,toReturn);
}
