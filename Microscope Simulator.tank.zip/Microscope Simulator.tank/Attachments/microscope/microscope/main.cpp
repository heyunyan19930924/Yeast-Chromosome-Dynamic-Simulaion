// Include DTSource.h if you want to include all the headers.

#include "DTArguments.h"
#include "DTSaveError.h"

#include "DTDataFile.h"
#include "DTMesh3D.h"
#include "DTMesh3DGrid.h"
#include "DTPointCollection3D.h"

// Common utilities
#include "DTDoubleArrayOperators.h"
#include "DTProgress.h"
#include "DTTimer.h"
#include "DTUtilities.h"
#include "DTDictionary.h"

#include <math.h>

DTMesh3D Computation(const DTMesh3DGrid &grid,const DTPointCollection3D &points,
                     double radius,double strength);

int main(int argc,const char *argv[])
{
    DTSetArguments(argc,argv);
    
    DTDataFile inputFile("Input.dtbin",DTFile::ReadOnly);
    // Read in the input variables.
    DTMesh3DGrid grid;
    Read(inputFile,"grid",grid);
    DTPointCollection3D points;
    Read(inputFile,"points",points);
    double radius = inputFile.ReadNumber("radius");
    double strength = inputFile.ReadNumber("strength");
    
    // The computation.
    DTMesh3D computed;
    clock_t t_before = clock();
    computed = Computation(grid,points,radius,strength);
    clock_t t_after = clock();
    double exec_time = double(t_after-t_before)/double(CLOCKS_PER_SEC);
    
    // Write the output.
    DTDataFile outputFile("Output.dtbin",DTFile::NewReadWrite);
    
    // Output from computation
    Write(outputFile,"Var",computed);
    outputFile.Save("Mesh3D","Seq_Var");
    
    // The execution time.
    outputFile.Save(exec_time,"ExecutionTime");
    outputFile.Save("Real Number","Seq_ExecutionTime");
    
    // The errors.
    DTSaveError(outputFile,"ExecutionErrors");
    outputFile.Save("StringList","Seq_ExecutionErrors");
    
    return 0;
}

DTMesh3D Computation(const DTMesh3DGrid &grid,const DTPointCollection3D &points,
                     double radius,double strength)
{
    int m = grid.m();
    int n = grid.n();
    int o = grid.o();
    float dx = grid.dx();
    float dy = grid.dy();
    float dz = grid.dz();
    DTMutableFloatArray values(m,n,o);
    values = 0;
    
    int howManyPoints = points.NumberOfPoints();
    int pointNumber;
    DTPoint3D center;
    float x,y,z;
    float scaleForGaussian = 1.0/(2*radius*radius);
    float scale = strength*pow(radius/sqrt(2*M_PI),3.0);
    int i,j,k;
    int startI,endI,startJ,endJ,startK,endK;
    
    for (pointNumber=0;pointNumber<howManyPoints;pointNumber++) {
        center = points(pointNumber);
        center = grid.ConvertCoordinateToGrid(center);
        startI = int(ceil(center.x-radius/dx*3));
        endI = int(ceil(center.x+radius/dx*3));
        startJ = int(ceil(center.y-radius/dy*3));
        endJ = int(ceil(center.y+radius/dy*3));
        startK = int(ceil(center.z-radius/dz*3));
        endK = int(ceil(center.z+radius/dz*3));
        
        startI = std::max(0,startI);
        startJ = std::max(0,startJ);
        startK = std::max(0,startK);
        endI = std::min(m,endI);
        endJ = std::min(n,endJ);
        endK = std::min(o,endK);
        
        for (k=startK;k<endK;k++) {
            z = (k-center.z)*dz;
            for (j=startJ;j<endJ;j++) {
                y = (j-center.y)*dy;
                for (i=startI;i<endI;i++) {
                    x = (i-center.x)*dx;
                    values(i,j,k) += scale*exp(-(x*x+y*y+z*z)*scaleForGaussian);
                }
            }
        }
    }

    return DTMesh3D(grid,values);
}
